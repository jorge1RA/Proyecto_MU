var searchData=
[
  ['terminos_5fcondiciones_2ephp_0',['terminos_condiciones.php',['../terminos__condiciones_8php.html',1,'']]],
  ['tienda_2ephp_1',['tienda.php',['../tienda_8php.html',1,'']]]
];
