var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['recipient_1',['recipient',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a3fe758d41853a59d4ccfdce815f006a2',1,'PHPMailer::PHPMailer::SMTP']]],
  ['recordlasttransactionid_2',['recordLastTransactionID',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a7ca35ef525499613bea7afe470e570bd',1,'PHPMailer::PHPMailer::SMTP']]],
  ['registro_2ephp_3',['registro.php',['../registro_8php.html',1,'']]],
  ['remitente_4',['remitente',['../ver__contactos_8php.html#aed157fa04bd9c0f277fa2d6aba46e8dc',1,'ver_contactos.php']]],
  ['replacecustomheader_5',['replaceCustomHeader',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ad3f8fbe633ca7c39294785b0c3621a78',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['reset_6',['reset',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#ace903ddfc53a6c998f694cf894266fa4',1,'PHPMailer::PHPMailer::SMTP']]],
  ['rfcdate_7',['rfcDate',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a1c35f9ec17924309c683f123856866de',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
