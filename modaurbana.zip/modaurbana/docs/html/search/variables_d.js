var searchData=
[
  ['while_0',['while',['../index_8php.html#acdf08b11c8ccd73b18cc44a31ed6b683',1,'while:&#160;index.php'],['../confirmacion_8php.html#aeb30e9da15954c6af3ebf241851dc501',1,'while:&#160;confirmacion.php'],['../tienda_8php.html#acae4476b000ef4ec11c59e47fa805cc6',1,'while:&#160;tienda.php']]]
];
