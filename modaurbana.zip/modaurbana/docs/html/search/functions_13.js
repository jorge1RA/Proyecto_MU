var searchData=
[
  ['validateaddress_0',['validateAddress',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#abc9724fcd40217503b3dcb5062791e3b',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['validateencoding_1',['validateEncoding',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ace406e09f9eada020abdac1e396ee426',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['verify_2',['verify',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#aa6f0d709ee797863db52b9e4626c7d55',1,'PHPMailer::PHPMailer::SMTP']]]
];
