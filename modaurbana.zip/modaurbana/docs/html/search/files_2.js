var searchData=
[
  ['carrito_2ephp_0',['carrito.php',['../carrito_8php.html',1,'']]],
  ['checkout_2ephp_1',['checkout.php',['../checkout_8php.html',1,'']]],
  ['comprar_2ephp_2',['comprar.php',['../comprar_8php.html',1,'']]],
  ['conexion_2ephp_3',['conexion.php',['../conexion_8php.html',1,'']]],
  ['config_2ephp_4',['config.php',['../config_8php.html',1,'']]],
  ['confirmacion_2ephp_5',['confirmacion.php',['../confirmacion_8php.html',1,'']]],
  ['contacto_2ephp_6',['contacto.php',['../contacto_8php.html',1,'']]],
  ['crear_2ephp_7',['crear.php',['../crear_8php.html',1,'']]]
];
