var searchData=
[
  ['recipient_0',['recipient',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a3fe758d41853a59d4ccfdce815f006a2',1,'PHPMailer::PHPMailer::SMTP']]],
  ['recordlasttransactionid_1',['recordLastTransactionID',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a7ca35ef525499613bea7afe470e570bd',1,'PHPMailer::PHPMailer::SMTP']]],
  ['replacecustomheader_2',['replaceCustomHeader',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ad3f8fbe633ca7c39294785b0c3621a78',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['reset_3',['reset',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#ace903ddfc53a6c998f694cf894266fa4',1,'PHPMailer::PHPMailer::SMTP']]],
  ['rfcdate_4',['rfcDate',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a1c35f9ec17924309c683f123856866de',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
