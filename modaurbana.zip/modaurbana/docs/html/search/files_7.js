var searchData=
[
  ['index_2ephp_0',['index.php',['../admin_2index_8php.html',1,'(Global Namespace)'],['../admin_2pedidos_2index_8php.html',1,'(Global Namespace)'],['../admin_2productos_2index_8php.html',1,'(Global Namespace)'],['../index_8php.html',1,'(Global Namespace)']]]
];
