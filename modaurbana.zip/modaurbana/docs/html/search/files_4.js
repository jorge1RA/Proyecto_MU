var searchData=
[
  ['footer_2ephp_0',['footer.php',['../footer_8php.html',1,'']]]
];
