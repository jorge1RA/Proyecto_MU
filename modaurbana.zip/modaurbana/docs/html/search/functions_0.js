var searchData=
[
  ['_5f_5fconstruct_0',['__construct',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a29c8ddd01ae18fa75d02e14005efce22',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['_5f_5fdestruct_1',['__destruct',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ae6d9332d9dab73c4745740248e117023',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['_5fmime_5ftypes_2',['_mime_types',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a53ddd3a03dd163fbc8397005770304ce',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
