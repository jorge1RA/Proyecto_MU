var searchData=
[
  ['pedidos_0',['pedidos',['../administrar__contactos_8php.html#acd70ba38dcc9b5085bcc3dc73f934e87',1,'administrar_contactos.php']]],
  ['producto_1',['producto',['../admin_2productos_2index_8php.html#a53293617a5f269a6db0453be1fe16c17',1,'index.php']]]
];
