var searchData=
[
  ['pedido_0',['pedido',['../admin_2pedidos_2index_8php.html#aa1612407c8a09d4972899223e6ce2636',1,'index.php']]]
];
