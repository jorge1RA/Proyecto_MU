var searchData=
[
  ['actualizar_5fcarrito_2ephp_0',['actualizar_carrito.php',['../actualizar__carrito_8php.html',1,'']]],
  ['administrar_5fcontactos_2ephp_1',['administrar_contactos.php',['../administrar__contactos_8php.html',1,'']]],
  ['agregar_5fcarrito_2ephp_2',['agregar_carrito.php',['../agregar__carrito_8php.html',1,'']]]
];
