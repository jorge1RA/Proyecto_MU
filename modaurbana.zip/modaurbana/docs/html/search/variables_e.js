var searchData=
[
  ['usuario_0',['usuario',['../admin_2pedidos_2index_8php.html#a358a2b81061ede57785044ed0cd3f318',1,'index.php']]]
];
