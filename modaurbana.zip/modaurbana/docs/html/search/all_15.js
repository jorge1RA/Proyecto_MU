var searchData=
[
  ['while_0',['while',['../index_8php.html#acdf08b11c8ccd73b18cc44a31ed6b683',1,'while:&#160;index.php'],['../tienda_8php.html#acae4476b000ef4ec11c59e47fa805cc6',1,'while:&#160;tienda.php']]],
  ['wraptext_1',['wrapText',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a94a6b50e8ce53dd6ddd1d4d5341adc73',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
