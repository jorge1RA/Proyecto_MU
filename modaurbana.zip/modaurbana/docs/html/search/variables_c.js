var searchData=
[
  ['version_0',['VERSION',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a79ae6ea778fe4ad5fa5d6b1a1cebb26d',1,'PHPMailer\PHPMailer\PHPMailer\VERSION'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#adb37dc6e8c061cbac377ab9ee88226e2',1,'PHPMailer\PHPMailer\SMTP\VERSION']]]
];
