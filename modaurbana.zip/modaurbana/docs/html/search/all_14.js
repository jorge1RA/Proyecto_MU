var searchData=
[
  ['validateaddress_0',['validateAddress',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#abc9724fcd40217503b3dcb5062791e3b',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['validateencoding_1',['validateEncoding',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ace406e09f9eada020abdac1e396ee426',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['ver_5fcontactos_2ephp_2',['ver_contactos.php',['../ver__contactos_8php.html',1,'']]],
  ['ver_5fmensajes_2ephp_3',['ver_mensajes.php',['../ver__mensajes_8php.html',1,'']]],
  ['ver_5fpedido_2ephp_4',['ver_pedido.php',['../ver__pedido_8php.html',1,'']]],
  ['verify_5',['verify',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#aa6f0d709ee797863db52b9e4626c7d55',1,'PHPMailer::PHPMailer::SMTP']]],
  ['version_6',['VERSION',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a79ae6ea778fe4ad5fa5d6b1a1cebb26d',1,'PHPMailer\PHPMailer\PHPMailer\VERSION'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#adb37dc6e8c061cbac377ab9ee88226e2',1,'PHPMailer\PHPMailer\SMTP\VERSION']]]
];
