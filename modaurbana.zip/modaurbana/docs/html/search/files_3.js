var searchData=
[
  ['editar_2ephp_0',['editar.php',['../editar_8php.html',1,'']]],
  ['editar_5festado_2ephp_1',['editar_estado.php',['../editar__estado_8php.html',1,'']]],
  ['editar_5fperfil_2ephp_2',['editar_perfil.php',['../editar__perfil_8php.html',1,'']]],
  ['eliminar_5fdel_5fcarrito_2ephp_3',['eliminar_del_carrito.php',['../eliminar__del__carrito_8php.html',1,'']]],
  ['eliminar_5fproducto_2ephp_4',['eliminar_producto.php',['../eliminar__producto_8php.html',1,'']]],
  ['eliminar_5fvariante_2ephp_5',['eliminar_variante.php',['../eliminar__variante_8php.html',1,'']]],
  ['enviar_5fcorreo_2ephp_6',['enviar_correo.php',['../enviar__correo_8php.html',1,'']]],
  ['exception_2ephp_7',['Exception.php',['../_exception_8php.html',1,'']]]
];
