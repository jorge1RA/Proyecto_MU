var searchData=
[
  ['perfil_2ephp_0',['perfil.php',['../perfil_8php.html',1,'']]],
  ['phpmailer_2ephp_1',['PHPMailer.php',['../_p_h_p_mailer_8php.html',1,'']]],
  ['politica_5fprivacidad_2ephp_2',['politica_privacidad.php',['../politica__privacidad_8php.html',1,'']]],
  ['productos_2ephp_3',['productos.php',['../productos_8php.html',1,'']]]
];
