var searchData=
[
  ['while_0',['while',['../index_8php.html#acdf08b11c8ccd73b18cc44a31ed6b683',1,'while:&#160;index.php'],['../tienda_8php.html#acae4476b000ef4ec11c59e47fa805cc6',1,'while:&#160;tienda.php']]]
];
