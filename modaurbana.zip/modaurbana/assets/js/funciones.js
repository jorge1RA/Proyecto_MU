/**
 * funciones.js
 *
 * Maneja la visibilidad de los datos de tarjeta según el método de pago seleccionado.
 *
 * @category Scripts
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 *
 */

/**
 * Evento principal al cargar la página.
 * Muestra u oculta los campos de datos de tarjeta según el método de pago seleccionado.
 *
 * @event DOMContentLoaded Se dispara cuando el contenido del DOM ha sido completamente cargado y parseado.
 */
document.addEventListener("DOMContentLoaded", function () {
  console.log("JavaScript cargado");

  /**
   * Referencias a los elementos HTML:
   * - Selector del método de pago.
   * - Contenedor de los datos de la tarjeta.
   *
   * @type {HTMLElement} metodoPagoSelect Elemento que representa el selector de método de pago.
   * @type {HTMLElement} datosTarjetaDiv Elemento que representa el contenedor de los datos de la tarjeta.
   */
  var metodoPagoSelect = document.getElementById("metodo_pago");
  var datosTarjetaDiv = document.getElementById("datos_tarjeta");

  /**
   * Evento que maneja los cambios en el método de pago,
   * sí el método seleccionado es 'tarjeta', se muestran los campos correspondientes.
   * Caso contrario, se ocultan.
   *
   * @event change Se dispara cuando el valor del selector de método de pago cambia.
   */
  metodoPagoSelect.addEventListener("change", function () {
    console.log("Método de pago cambiado a: " + this.value);
    datosTarjetaDiv.style.display = this.value === "tarjeta" ? "block" : "none";
  });

  /**
   * Inicializa la visibilidad de los datos de tarjeta al cargar la página.
   * Si el método de pago preseleccionado es 'tarjeta', muestra los campos de tarjeta.
   * Caso contrario, los oculta.
   */
  datosTarjetaDiv.style.display =
    metodoPagoSelect.value === "tarjeta" ? "block" : "none";
});
