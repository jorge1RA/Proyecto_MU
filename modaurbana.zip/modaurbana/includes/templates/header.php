<?php

/**
 * header.php
 * 
 * Cabecera que se incluye en todas las páginas para proporcionar una barra de navegación.
 * 
 * Muestra opciones específicas según el rol del usuario (usuario regular o administrador).
 * Incluye también un contador dinámico de mensajes no leídos para el administrador.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */

/**
 * Inicia la sesión si aún no ha sido iniciada.
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * Incluir la conexión a la base de datos de forma segura.
 */
include_once __DIR__ . '/../conexion.php';

/**
 * Consulta para contar los mensajes no leídos.
 */
$sql_contar_no_leidos = "SELECT COUNT(*) AS no_leidos FROM contactos WHERE leido = 0";
$resultado_contar = mysqli_query($conexion, $sql_contar_no_leidos);

/**
 * Obtiene el número de mensajes no leídos si la consulta fue exitosa.
 */
if ($resultado_contar) {
    $contador_no_leidos = mysqli_fetch_assoc($resultado_contar)['no_leidos'];
} else {
    /**
     * Asignar un valor por defecto si la consulta falla.
     */
    $contador_no_leidos = 0;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Header</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>
    <!-- 
    Contenedor principal. 
    -->
    <div id="contenido" class="d-flex flex-column">

        <!-- 
        Barra de navegación.
        Cambiamos la clase predeterminada de Bootstrap `navbar-dark bg-dark` por la clase personalizada `custom-navbar`.
        -->
        <nav class="navbar navbar-expand-lg custom-navbar">
            <a class="navbar-brand" href="/modaurbana/index.php">
                <!-- 
                Logo incrustado en barra de navegación. 
                -->
                <img src="/modaurbana/assets/img/Logo_Tienda.png" alt="ModaUrbana" height="40">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- 
            Contenedor del menú. 
            -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/modaurbana/index.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/modaurbana/pages/products/tienda.php">Tienda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/modaurbana/nosotros.php">Nosotros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/modaurbana/pages/contact/contacto.php">Contacto</a>
                    </li>
                </ul>

                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_rol'] != 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/admin/pedidos/mis_pedidos.php">Mis Pedidos</a>
                        </li>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['usuario_rol']) && $_SESSION['usuario_rol'] == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/admin/productos/index.php">Gestionar Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/admin/pedidos/index.php">Gestionar Pedidos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/admin/contactos/ver_contactos.php">
                                <i class="fas fa-envelope"></i>
                                <span class="badge badge-danger"><?php echo $contador_no_leidos; ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link" href="/modaurbana/pages/cart/carrito.php">
                            <i class="fas fa-shopping-cart mr-2"></i>
                            <span class="badge badge-info"><?php echo isset($_SESSION['carrito']) ? count($_SESSION['carrito']) : 0; ?></span>
                        </a>
                    </li>

                    <?php if (isset($_SESSION['usuario_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/admin/perfil/perfil.php">
                                <i class="fas fa-user"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/pages/login/logout.php">Cerrar Sesión</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/pages/login/login.php">Iniciar Sesión</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/modaurbana/pages/user/registro.php">Registrarse</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>