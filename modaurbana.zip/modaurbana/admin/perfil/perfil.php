<?php

/**
 * perfil.php
 *
 * Página que muestra la información de mi perfil.
 *
 * Me permite ver mi información personal y acceder a la página de edición de mi perfil.
 *
 * @category Usuario
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicio una nueva sesión o reanudo la existente.
 * 
 * Esto asegura que pueda acceder a la información de mi perfil.
 * 
 * @return void
 */
session_start();


/**
 * Verifico si he iniciado sesión.
 * 
 * Si no estoy autenticado, me redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluyo el archivo de conexión a la base de datos.
 * 
 * Esto me permite conectarme con la base de datos para obtener la información de mi perfil.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Obtengo el id del usuario desde la sesión y lo almaceno en $usuario_id.
 * 
 * @var int $usuario_id ID del usuario actual.
 */
$usuario_id = $_SESSION['usuario_id'];


/**
 * Preparo y ejecuto la consulta para obtener la información del usuario desde la base de datos.
 * 
 * @var string $sql_usuario Consulta SQL para obtener la información del usuario.
 * @return mysqli_result $resultado_usuario Resultado de la consulta.
 */
$sql_usuario = "SELECT * FROM usuarios WHERE id = '$usuario_id'";
$resultado_usuario = mysqli_query($conexion, $sql_usuario);


/**
 * Verifico si se obtuvo un resultado válido de la consulta.
 * 
 * Si no se encuentra el usuario, muestro un mensaje de error y termino la ejecución.
 * 
 * @return void
 */
if (!$resultado_usuario || mysqli_num_rows($resultado_usuario) == 0) {
    echo "Usuario no encontrado.";
    exit();
}


/**
 * Obtiene la información del usuario y la almaceno en la variable $usuario.
 * 
 * @var array $usuario Datos del usuario.
 */
$usuario = mysqli_fetch_assoc($resultado_usuario);


/**
 * Incluyo el esqueleto de la cabecera de la página.
 * 
 * Añade la cabecera, que incluye la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>


<!-- 
Contenedor principal con margen superior.
-->
<div class="container mt-4">
    <h2 class="mb-4">Mi Perfil</h2>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5>Información Personal</h5>
        </div>
        <div class="card-body">
            <!-- 
            Imagen de perfil del usuario.
            -->
            <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($usuario['imagen']); ?>" alt="Imagen de Perfil" class="img-thumbnail mb-3" width="150">

            <!-- 
            Información personal del usuario.
            -->
            <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
            <p><strong>Apellidos:</strong> <?php echo htmlspecialchars($usuario['apellidos']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
            <p><strong>Rol:</strong> <?php echo ucfirst(htmlspecialchars($usuario['rol'])); ?></p>

            <!-- 
            Enlace para editar perfil.
            -->
            <a href="/modaurbana/admin/perfil/editar_perfil.php" class="btn btn-primary mt-3">Editar Perfil</a>
        </div>
    </div>
</div>

<!-- 
Incluyo el esqueleto del pie de la página.
-->
<?php include_once '../../includes/templates/footer.php'; ?>