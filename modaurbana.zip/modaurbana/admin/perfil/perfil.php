<?php

/**
 * perfil.php
 *
 * Página que muestra la información de mi perfil.
 *
 * Me permite ver mi información personal y acceder a la página de edición de mi perfil.
 *
 * @category Usuario
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicio una nueva sesión o reanudo la existente.
 * 
 * Esto asegura que pueda acceder a la información de mi perfil.
 * 
 * @return void
 */
session_start();


/**
 * Verifico si he iniciado sesión.
 * 
 * Si no estoy autenticado, me redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluyo el archivo de conexión a la base de datos.
 * 
 * Esto me permite conectarme con la base de datos para obtener la información de mi perfil.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Obtengo el id del usuario desde la sesión y lo almaceno en $usuario_id.
 * 
 * @var int $usuario_id ID del usuario actual.
 */
$usuario_id = $_SESSION['usuario_id'];


/**
 * Preparo y ejecuto la consulta para obtener la información del usuario desde la base de datos.
 * 
 * @var string $sql_usuario Consulta SQL para obtener la información del usuario.
 * @return mysqli_result $resultado_usuario Resultado de la consulta.
 */
$sql_usuario = "SELECT * FROM usuarios WHERE id = '$usuario_id'";
$resultado_usuario = mysqli_query($conexion, $sql_usuario);


/**
 * Verifico si se obtuvo un resultado válido de la consulta.
 * 
 * Si no se encuentra el usuario, muestro un mensaje de error y termino la ejecución.
 * 
 * @return void
 */
if (!$resultado_usuario || mysqli_num_rows($resultado_usuario) == 0) {
    echo "Usuario no encontrado.";
    exit();
}


/**
 * Obtiene la información del usuario y la almaceno en la variable $usuario.
 * 
 * @var array $usuario Datos del usuario.
 */
$usuario = mysqli_fetch_assoc($resultado_usuario);


/**
 * Incluyo el esqueleto de la cabecera de la página.
 * 
 * Añade la cabecera, que incluye la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Mi Perfil</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>


    <!-- 
Contenedor principal con margen superior.
-->
    <div class="background-container">
        <div class="container mt-4">
            <br><br>
            <h2 data-aos="fade-up">Mi Perfil</h2>
            <br>
            <div class="card">
                <div class="navbar navbar-expand-lg custom-navbar">
                    <h5 style="margin-left: 25px;">Información Personal</h5>
                </div>
                <div class="card-body">
                    <!-- 
            Imagen de perfil del usuario.
            -->
                    <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($usuario['imagen']); ?>" alt="Imagen de Perfil" class="img-thumbnail mb-3" width="150">

                    <!-- 
            Información personal del usuario.
            -->
                    <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
                    <p><strong>Apellidos:</strong> <?php echo htmlspecialchars($usuario['apellidos']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
                    <p><strong>Rol:</strong> <?php echo ucfirst(htmlspecialchars($usuario['rol'])); ?></p>

                    <!-- 
            Enlace para editar perfil.
            -->
                    <a href="/modaurbana/admin/perfil/editar_perfil.php" class="btn btn-primary mt-3">Editar Perfil</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Incluye el CSS de AOS para añadir estilos de animación -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


    <!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

    <!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
    <script>
        AOS.init();
    </script>

    <!-- 
Incluyo el esqueleto del pie de la página.
-->
    <?php include_once '../../includes/templates/footer.php'; ?>