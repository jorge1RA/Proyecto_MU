<?php

/**
 * ver_mensaje.php
 * 
 * Página para ver los detalles de un mensaje de contacto específico.
 *
 * Como administrador, aquí puedo visualizar el contenido completo de un mensaje de contacto seleccionado.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto me asegura que el usuario que intenta ver el mensaje está autenticado y tiene los permisos necesarios.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y si tiene el rol de administrador.
 * 
 * Si el usuario no tiene los permisos correctos, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite realizar consultas para obtener los detalles del mensaje de contacto.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si se ha proporcionado un ID de mensaje válido en la URL.
 * 
 * Si no se ha proporcionado, redirijo al administrador a la lista de contactos.
 * 
 * @return void
 */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: /modaurbana/admin/contactos/ver_contactos.php');
    exit();
}


/**
 * Sanitiza y convierte el id del mensaje a un valor entero.
 * 
 * Esto es importante para prevenir ataques de inyección SQL.
 * 
 * @var int $mensaje_id ID del mensaje de contacto.
 */
$mensaje_id = intval($_GET['id']);


/**
 * Obtiene los detalles del mensaje desde la base de datos.
 * 
 * Utilizo la consulta SQL para recuperar todos los detalles del mensaje con el ID proporcionado.
 * 
 * @var string $sql Consulta SQL para obtener el mensaje de contacto.
 * @var mysqli_result|false $resultado Resultado de la consulta SQL.
 * @var array|false $mensaje Los detalles del mensaje en forma de arreglo asociativo.
 */
$sql = "SELECT * FROM contactos WHERE id='$mensaje_id'";
$resultado = mysqli_query($conexion, $sql);
$mensaje = mysqli_fetch_assoc($resultado);


/**
 * Si no se encuentra el mensaje en la base de datos, redirijo a la lista de contactos.
 * 
 * Esto asegura que no se intente acceder a un mensaje inexistente.
 * 
 * @return void
 */
if (!$mensaje) {
    header('Location: /modaurbana/admin/contactos/ver_contactos.php');
    exit();
}


/**
 * Después de confirmar que el mensaje existe, actualizo el estado del mensaje a "leído".
 * 
 * Utilizo una consulta preparada para evitar inyección SQL.
 * 
 * @var string $sql_marcar_leido Consulta SQL para actualizar el estado del mensaje.
 * @var mysqli_stmt|false $stmt_marcar_leido Declaración preparada para ejecutar la consulta.
 */
$sql_marcar_leido = "UPDATE contactos SET leido = 1 WHERE id = ?";
$stmt_marcar_leido = mysqli_prepare($conexion, $sql_marcar_leido);
if ($stmt_marcar_leido) {
    mysqli_stmt_bind_param($stmt_marcar_leido, "i", $mensaje_id);
    mysqli_stmt_execute($stmt_marcar_leido);
    mysqli_stmt_close($stmt_marcar_leido);
}


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!--  
Contenedor Principal con clases de Bootstrap para mostrar los detalles del mensaje de manera estructurada.
-->
<div class="container mt-4">
    <br><br>
    <h2>Detalles del Mensaje</h2>
    <br><br>
    <div class="card">
        <div class="card-header">
            <strong>Asunto:</strong> <?php echo htmlspecialchars($mensaje['asunto']); ?>
            <!-- 
            Utilizo htmlspecialchars() para evitar ataques XSS al mostrar datos provenientes de la base de datos. 
            -->
        </div>
        <div class="card-body">
            <p><strong>Nombre:</strong> <?php echo htmlspecialchars($mensaje['nombre']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($mensaje['email']); ?></p>
            <p><strong>Fecha de Envío:</strong> <?php echo htmlspecialchars($mensaje['fecha_envio']); ?></p>
            <p><strong>Mensaje:</strong></p>
            <!-- 
            Convierte caracteres especiales para evitar XSS y preserva los saltos de línea del mensaje original con nl2br(). 
            -->
            <p><?php echo nl2br(htmlspecialchars($mensaje['mensaje'])); ?></p>
        </div>
    </div>
    <a href="/modaurbana/admin/contactos/ver_contactos.php" class="btn btn-secondary mt-3">Volver a la Lista de Mensajes</a>
</div>


<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade la parte inferior del sitio, incluyendo enlaces y otras secciones comunes.
-->
<?php include_once '../../includes/templates/footer.php'; ?>