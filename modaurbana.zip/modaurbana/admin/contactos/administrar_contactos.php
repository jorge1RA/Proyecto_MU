<?php

/**
 * administrar_contactos.php
 * 
 * Página para administrar los mensajes de contacto.
 *
 * En esta página, yo, como administrador, puedo ver todos los mensajes que han sido enviados por los usuarios a través del formulario de contacto.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 * 
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Uso esta función para asegurar que el administrador esté autenticado antes de acceder a la página.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y si tiene rol de administrador.
 * 
 * Si el usuario no cumple con estas condiciones, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos para poder realizar las consultas necesarias.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Consulta SQL para obtener todos los mensajes de contacto, ordenándolos por la fecha de envío de forma descendente.
 * Esto me permite mostrar los mensajes más recientes primero.
 * 
 * @var string $sql_contactos La consulta SQL para obtener los mensajes de contacto.
 * @var mysqli_result|false $resultado_contactos El resultado de ejecutar la consulta SQL en la base de datos.
 */
$sql_contactos = "SELECT * FROM contactos ORDER BY fecha_envio DESC";
$resultado_contactos = mysqli_query($conexion, $sql_contactos);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!--  
Contenedor Principal.
Este contenedor me permite mostrar la interfaz para administrar los mensajes de contacto.
-->
<div class="container mt-4">
    <h2>Administrar Mensajes de Contacto</h2>
    <!-- 
    Verifico si el resultado de la consulta contiene al menos un mensaje de contacto.
    Si es así, muestro una tabla con los mensajes.
    -->
    <?php if (mysqli_num_rows($resultado_contactos) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Asunto</th>
                    <th>Mensaje</th>
                    <th>Fecha de Envío</th>
                </tr>
            </thead>
            <tbody>
                <!-- 
                Recorro cada mensaje de contacto para mostrarlo en una fila de la tabla.
                Esto me permite visualizar todos los mensajes que han sido enviados por los usuarios.
                -->
                <?php while ($contacto = mysqli_fetch_assoc($resultado_contactos)): ?>
                    <tr>
                        <!-- 
                        Muestro el nombre, email, asunto, mensaje y la fecha de envío del remitente.
                        Uso htmlspecialchars para evitar problemas de seguridad como XSS.
                        -->
                        <td><?php echo htmlspecialchars($contacto['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($contacto['email']); ?></td>
                        <td><?php echo htmlspecialchars($contacto['asunto']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($contacto['mensaje'])); ?></td>
                        <td><?php echo htmlspecialchars($contacto['fecha_envio']); ?></td>
                    </tr>
                    <!-- 
                    Termino el bucle de contacto para pasar al siguiente mensaje, si lo hay.
                    -->
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <!-- 
        Si no hay mensajes de contacto, muestro un mensaje informativo.
        Esto me permite saber que actualmente no hay mensajes por revisar.
        -->
        <p>No hay mensajes de contacto en este momento.</p>
    <?php endif; ?>
</div>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade el pie de página, que incluye información adicional del sitio web.
-->
<?php include_once '../../includes/templates/footer.php'; ?>