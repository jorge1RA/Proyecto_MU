<?php

/**
 * ver_contactos.php
 * 
 * Página para visualizar los mensajes de contacto.
 *
 * En esta página puedo ver una lista de todos los mensajes de contacto que hemos recibido,
 * y así permitir al administrador revisar los detalles de cada mensaje.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto es necesario para asegurar que el administrador esté autenticado y pueda acceder a los mensajes de contacto.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y si tiene el rol de administrador.
 * 
 * Si el usuario no tiene permisos de administrador, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite realizar consultas a la base de datos para obtener los mensajes de contacto.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Consulta SQL para obtener todos los mensajes de contacto, ordenados por fecha de envío de forma descendente.
 * 
 * Necesito esta consulta para mostrar los mensajes más recientes en la parte superior.
 * 
 * @var string $sql Consulta SQL para obtener los mensajes de contacto.
 * @var mysqli_result|false $resultado Resultado de la consulta SQL.
 */
$sql = "SELECT * FROM contactos ORDER BY fecha_envio DESC";
$resultado = mysqli_query($conexion, $sql);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Ver Contactos</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>


    <!--  
    Contenedor Principal con clases de Bootstrap para darle formato a la página.
    -->
    <div class="background-container">
        <div class="container-fluid mt-4">
            <br><br>
            <h2 data-aos="fade-up">Mensajes de Contacto</h2>
            <br><br>
            <!-- 
            Verifico si la consulta ha devuelto algún resultado.
            Si el número de filas es mayor que cero, significa que hay mensajes para mostrar.
             -->
            <?php if (mysqli_num_rows($resultado) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Asunto</th>
                            <th>Fecha de Envío</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- 
                        Utilizo un bucle para generar una fila para cada mensaje obtenido de la consulta.
                        -->
                        <?php while ($mensaje = mysqli_fetch_assoc($resultado)): ?>
                            <!-- 
                            Aplico una clase de Bootstrap para mostrar un color diferente si el mensaje no ha sido leído.
                            -->
                            <tr class="<?php echo $mensaje['leido'] ? 'table-light' : 'table-warning'; ?>">
                                <!-- 
                                Muestra información como el id, nombre del remitente, email, asunto y fecha de envío del mensaje.
                                -->
                                <td><?php echo htmlspecialchars($mensaje['id']); ?></td>
                                <td><?php echo htmlspecialchars($mensaje['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($mensaje['email']); ?></td>
                                <td><?php echo htmlspecialchars($mensaje['asunto']); ?></td>
                                <td><?php echo htmlspecialchars($mensaje['fecha_envio']); ?></td>
                                <td>
                                    <!-- 
                                    Enlaces para ver el mensaje completo o borrarlo.
                                    Incluyo confirmación antes de borrar un mensaje para evitar errores.
                                    -->
                                    <a href="/modaurbana/admin/contactos/ver_mensajes.php?id=<?php echo htmlspecialchars($mensaje['id']); ?>" class="btn btn-primary btn-sm">Ver Mensaje</a>
                                    <a href="/modaurbana/admin/contactos/borrar_mensaje.php?id=<?php echo htmlspecialchars($mensaje['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas borrar este mensaje?');">Borrar</a>
                                </td>
                            </tr>
                            <!-- 
                            Fin del bucle que muestra cada mensaje.
                            -->
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <!-- 
                Si no se encuentra ningún mensaje, muestro un mensaje informativo.
                -->
                <p>No hay mensajes.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Incluye el CSS de AOS para añadir estilos de animación -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


    <!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

    <!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
    <script>
        AOS.init();
    </script>

    <!-- 
    Incluye el esqueleto del pie de la página.
    Esto añade el pie de página, que incluye información adicional del sitio web.
    -->
    <?php include_once '../../includes/templates/footer.php'; ?>

</body>

</html>