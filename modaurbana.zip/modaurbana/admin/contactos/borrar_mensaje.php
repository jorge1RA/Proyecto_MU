<?php

/**
 * borrar_mensaje.php
 * 
 * Página para eliminar un mensaje de contacto.
 *
 * En esta página, tengo la posibilidad de eliminar un mensaje de contacto que haya sido recibido por la tienda.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero
 * 
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Utilizo esta función para asegurar que el administrador esté autenticado antes de realizar cualquier acción.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y si tiene rol de administrador.
 * 
 * Si el usuario no está autenticado como administrador, lo redirijo a la página de inicio de sesión para evitar accesos no autorizados.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos para poder interactuar con la información de los mensajes.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si el parámetro 'id' está presente en la URL y es un valor numérico.
 * 
 * Este parámetro es necesario para identificar el mensaje de contacto que quiero eliminar.
 * 
 * @return void
 */
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];


    /**
     * Sentencia SQL para eliminar el mensaje de contacto que tenga el ID proporcionado.
     * 
     * Uso una consulta preparada para prevenir ataques de inyección SQL.
     * 
     * @var string $sql La consulta SQL para eliminar el mensaje de contacto.
     * @var mysqli_stmt|false $stmt La declaración preparada (statement) para la consulta SQL.
     */
    $sql = "DELETE FROM contactos WHERE id = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    if ($stmt) {

        /**
         * Vincula el parámetro id a la consulta preparada.
         * 
         * De esta manera me aseguro de que se use un valor entero como id.
         * 
         * @param int $id El identificador del mensaje que quiero eliminar.
         * @return void
         */
        mysqli_stmt_bind_param($stmt, "i", $id);


        /**
         * Ejecuta la consulta para eliminar el mensaje.
         * 
         * Si la eliminación es exitosa, redirijo al administrador a la página de ver_contactos con un mensaje de éxito.
         * Si ocurre un error, redirijo con un mensaje de error.
         * 
         * @return void
         */
        if (mysqli_stmt_execute($stmt)) {
            header('Location: ver_contactos.php?mensaje=borrado_exito');
            exit();
        } else {
            header('Location: ver_contactos.php?mensaje=borrado_error');
            exit();
        }


        /**
         * Cierra el statement para liberar recursos.
         * 
         * @return void
         */
        mysqli_stmt_close($stmt);
    }
}


/**
 * Cierra la conexión a la base de datos para liberar recursos.
 * 
 * @return void
 */
mysqli_close($conexion);


/**
 * Si no se recibe un id válido, redirijo al administrador a la página de ver_contactos.
 * 
 * Esto evita que la página se quede sin respuesta si no se proporciona un id válido.
 * 
 * @return void
 */
header('Location: ver_contactos.php');
exit();
