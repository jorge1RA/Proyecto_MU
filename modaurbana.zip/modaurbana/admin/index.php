<?php

/**
 * index.php - admin
 *
 * Página inicial para la administración.
 *
 * Verifica si el usuario es administrador y redirige a la gestión de productos.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario ha iniciado sesión y si tiene el rol de administrador.
 * Si no es administrador, redirige al login.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos para permitir la interacción con ella.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Redirige al administrador a la página de gestión de productos para comenzar la administración.
 * 
 * @return void
 */
header('Location: /modaurbana/admin/productos/index.php');
exit();
