<?php

/**
 * index.php - gestión de productos
 *
 * Página principal para la gestión de productos y sus variantes.
 *
 * Permite al administrador visualizar, editar y eliminar productos y variantes.
 *
 * @category Administración
 * @package  ModaUrbana
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 */
session_start();

/**
 * Verifica si el usuario está autenticado como administrador.
 * Si no es administrador, redirige al login.
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}

/**
 * Incluye el archivo de conexión a la base de datos.
 */
include_once '../../includes/conexion.php';

/**
 * Obtiene todos los productos de la base de datos.
 */
$sql = "SELECT * FROM productos";
$resultado_productos = mysqli_query($conexion, $sql);

/**
 * Incluye el esqueleto de la cabecera de la página.
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Productos</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>

    <!-- Contenedor principal con margen superior. -->
    <div class="background-container">
        <div class="container-fluid mt-4">
            <br><br>
            <h2 data-aos="fade-up">Gestión de Productos</h2>

            <div class="d-flex justify-content-between mb-4">
                <a href="/modaurbana/admin/productos/crear.php" class="btn btn-agregar-personalizado" style="margin-left: 5px;">Agregar Producto</a>

                <!-- Filtro desplegable de productos -->
                <div>
                    <select id="filtro-productos" class="form-control" onchange="irAProducto()">
                        <!-- Opción por defecto que indica al administrador poder seleccionar un producto -->
                        <option value="">-- Selecciona un producto --</option>
                        <?php
                        // Reinicio el puntero del conjunto de resultados al inicio.
                        mysqli_data_seek($resultado_productos, 0);

                        // Bucle para iterar sobre cada producto obtenido de la base de datos
                        while ($producto_opcion = mysqli_fetch_assoc($resultado_productos)) {
                            // Genero una opción del desplegable por cada producto,
                            // establezco el 'value' como el id del producto,
                            // Se muestra el nombre del producto como el texto de la opción, utilizando 'htmlspecialchars' para evitar problemas de seguridad.
                            echo '<option value="' . $producto_opcion['id'] . '">' . htmlspecialchars($producto_opcion['nombre']) . '</option>';
                        }
                        ?>
                    </select>
                </div>


            </div>

            <?php if (mysqli_num_rows($resultado_productos) > 0): ?>
                <table class="table table-bordered">
                    <thead class="table-layout: auto">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Color</th>
                            <th>Talla</th>
                            <th>Stock</th>
                            <th>Acciones Producto</th>
                            <th>Acciones Variante</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php mysqli_data_seek($resultado_productos, 0); ?>
                        <?php while ($producto = mysqli_fetch_assoc($resultado_productos)): ?>
                            <?php $primera_fila = true; ?>
                            <?php
                            $producto_id = $producto['id'];
                            $sql_variantes = "SELECT * FROM producto_variantes WHERE producto_id = ?";
                            $stmt_variantes = $conexion->prepare($sql_variantes);
                            $stmt_variantes->bind_param("i", $producto_id);
                            $stmt_variantes->execute();
                            $resultado_variantes = $stmt_variantes->get_result();
                            $num_variantes = $resultado_variantes->num_rows;
                            ?>

                            <?php if ($num_variantes > 0): ?>
                                <?php $primera_fila = true; ?>
                                <?php while ($variante = $resultado_variantes->fetch_assoc()): ?>
                                    <tr id="<?php echo $primera_fila ? 'producto-' . $producto['id'] : ''; ?>" class="<?php echo $primera_fila ? 'producto-inicio' : ''; ?>">
                                        <?php if ($primera_fila): ?>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['id']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['nombre']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo number_format($producto['precio'], 2); ?>€</td>
                                        <?php endif; ?>

                                        <td><?php echo htmlspecialchars($variante['color']); ?></td>
                                        <td><?php echo htmlspecialchars($variante['talla']); ?></td>
                                        <td class="<?php echo ($variante['stock'] <= 5) ? 'table-warning' : ''; ?> text-center">
                                            <?php echo htmlspecialchars($variante['stock']); ?>
                                        </td>

                                        <?php if ($primera_fila): ?>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle text-center">
                                                <a href="/modaurbana/admin/productos/editar.php?id=<?php echo $producto['id']; ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                                <a href="/modaurbana/admin/productos/eliminar_producto.php?id=<?php echo $producto['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este producto y todas sus variantes?');">Eliminar</a>
                                            </td>
                                        <?php endif; ?>

                                        <td class="text-center">
                                            <a href="/modaurbana/admin/productos/eliminar_variante.php?id=<?php echo $variante['id']; ?>" class="btn btn-warning btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta variante?');">Eliminar</a>
                                        </td>
                                    </tr>

                                    <?php $primera_fila = false; ?>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr id="producto-<?php echo $producto['id']; ?>">
                                    <td><?php echo htmlspecialchars($producto['id']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                                    <td><?php echo number_format($producto['precio'], 2); ?>€</td>
                                    <td colspan="3" class="text-center">No hay variantes disponibles.</td>
                                    <td class="text-center">
                                        <a href="/modaurbana/admin/productos/editar.php?id=<?php echo $producto['id']; ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                        <a href="/modaurbana/admin/productos/eliminar_producto.php?id=<?php echo $producto['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este producto?');">Eliminar</a>
                                    </td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay productos disponibles.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Script para navegar al producto seleccionado -->
    <script>
        /**
         * Función que se ejecuta cuando se selecciona un producto del filtro desplegable.
         * Se encarga de desplazar la página hasta la fila del producto en la tabla
         * y resaltar temporalmente esa fila para facilitar su identificación.
         */
        function irAProducto() {
            // Obtiene el elemento <select> que contiene el filtro de productos.
            var select = document.getElementById('filtro-productos');

            // Obtiene el valor seleccionado, que corresponde al id del producto.
            var productoId = select.value;

            // Verifica que se haya seleccionado un producto (el valor no está vacío).
            if (productoId) {
                // Construye el id del elemento HTML que corresponde a la fila del producto en la tabla.
                var elementoProducto = document.getElementById('producto-' + productoId);

                // Verifica que el elemento exista en el DOM (puede no existir si el producto no está en la tabla).
                if (elementoProducto) {
                    // Desplaza la página hasta que la fila del producto sea visible.
                    elementoProducto.scrollIntoView({
                        behavior: 'smooth', // Hace que el desplazamiento sea suave (animado).
                        block: 'center' // Ubica el elemento en el centro de la ventana.
                    });

                    // Cambia temporalmente el color de fondo de la fila para resaltarla.
                    elementoProducto.style.backgroundColor = '#ffff99'; // Color Actual = 'amarillo claro'

                    // Después de 2 segundos (2000 milisegundos), restaura el color de fondo original
                    setTimeout(function() {
                        elementoProducto.style.backgroundColor = '';
                    }, 2000);
                } else {
                    // Si el elemento no se encuentra, muestra un mensaje de alerta
                    alert('Producto no encontrado en la tabla.');
                }
            }
        }
    </script>


    <!-- Incluye el CSS de AOS para añadir estilos de animación -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

    <!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
    <script>
        AOS.init();
    </script>

    <!-- Incluye el esqueleto del pie de la página -->
    <?php include_once '../../includes/templates/footer.php'; ?>

</body>

</html>