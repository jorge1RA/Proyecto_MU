<?php

/**
 * index.php - gestión de productos
 *
 * Página principal para la gestión de productos y sus variantes.
 *
 * Permite al administrador visualizar, editar y eliminar productos y variantes.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado como administrador.
 * Si no es administrador, redirige al login.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos para permitir la interacción con la base de datos.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Obtiene todos los productos de la base de datos para mostrarlos en la interfaz de administración.
 * 
 * @var string $sql Consulta SQL para seleccionar todos los productos.
 * @var mysqli_result|false $resultado_productos Resultado de la ejecución de la consulta SQL.
 */
$sql = "SELECT * FROM productos";
$resultado_productos = mysqli_query($conexion, $sql);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>index.php - gestión de productos</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>

    <!-- 
    Contenedor principal con margen superior. 
    -->
    <div class="background-container">
        <div class="container-fluid mt-4">
            <br><br>
            <h2 data-aos="fade-up">Gestión de Productos</h2>

            <a href="/modaurbana/admin/productos/crear.php" class="btn btn-agregar-personalizado mb-4" style="margin-left: 5px;">Agregar Producto</a>

            <!-- 
            Verifica si hay productos disponibles para mostrar.
            -->
            <?php if (mysqli_num_rows($resultado_productos) > 0): ?>
                <table class="table table-bordered">
                    <thead class="table-layout: auto">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Color</th>
                            <th>Talla</th>
                            <th>Stock</th>
                            <th>Acciones Producto</th>
                            <th>Acciones Variante</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- 
                        Itera sobre cada producto y obtiene sus variantes si existen.
                        -->
                        <?php mysqli_data_seek($resultado_productos, 0); ?>
                        <?php while ($producto = mysqli_fetch_assoc($resultado_productos)): ?>
                            <?php $primera_fila = true; ?>
                            <?php
                            /**
                             * Obtiene las variantes del producto usando una consulta preparada.
                             * 
                             * @var string $sql_variantes Consulta SQL para obtener las variantes del producto.
                             * @var mysqli_stmt|false $stmt_variantes Objeto statement preparado para la consulta.
                             */
                            $producto_id = $producto['id'];
                            $sql_variantes = "SELECT * FROM producto_variantes WHERE producto_id = ?";
                            $stmt_variantes = $conexion->prepare($sql_variantes);
                            $stmt_variantes->bind_param("i", $producto_id);
                            $stmt_variantes->execute();
                            $resultado_variantes = $stmt_variantes->get_result();
                            $num_variantes = $resultado_variantes->num_rows;
                            ?>

                            <!-- 
                            Si el producto tiene variantes, muestra cada variante.
                            -->
                            <?php if ($num_variantes > 0): ?>
                                <?php $primera_fila = true; ?>
                                <!-- 
                                Itera sobre cada variante del producto.
                                -->
                                <?php while ($variante = $resultado_variantes->fetch_assoc()): ?>
                                    <tr class="<?php echo $primera_fila ? 'producto-inicio' : ''; ?>">
                                        <?php if ($primera_fila): ?>
                                            <!-- 
                                            Muestra los datos del producto en la primera fila, abarcando todas las variantes con rowspan.
                                            -->
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['id']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['nombre']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle"><?php echo number_format($producto['precio'], 2); ?>€</td>
                                        <?php endif; ?>

                                        <!-- 
                                        Muestra los detalles específicos de cada variante.
                                        -->
                                        <td><?php echo htmlspecialchars($variante['color']); ?></td>
                                        <td><?php echo htmlspecialchars($variante['talla']); ?></td>
                                        <!-- 
                                        Se crea un advertencia de si  el stock es igual o inferior a 5
                                        -->
                                        <td class="<?php echo ($variante['stock'] <= 5) ? 'table-warning' : ''; ?> text-center">
                                            <?php echo htmlspecialchars($variante['stock']); ?>
                                        </td>

                                        <?php if ($primera_fila): ?>
                                            <!-- 
                                            Muestra las acciones para el producto, abarcando todas las variantes con rowspan.
                                            -->
                                            <td rowspan="<?php echo $num_variantes; ?>" class="align-middle text-center">
                                                <a href="/modaurbana/admin/productos/editar.php?id=<?php echo $producto['id']; ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                                <a href="/modaurbana/admin/productos/eliminar_producto.php?id=<?php echo $producto['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este producto y todas sus variantes?');">Eliminar</a>
                                            </td>
                                        <?php endif; ?>

                                        <!-- 
                                        Muestra el botón para eliminar la variante específica.
                                        -->
                                        <td class="text-center">
                                            <a href="/modaurbana/admin/productos/eliminar_variante.php?id=<?php echo $variante['id']; ?>" class="btn btn-warning btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta variante?');">Eliminar</a>
                                        </td>
                                    </tr>

                                    <?php $primera_fila = false; ?>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <!-- 
                                Si no tiene variantes, muestra solo el producto.
                                -->
                                <tr>
                                    <td><?php echo htmlspecialchars($producto['id']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                                    <td><?php echo number_format($producto['precio'], 2); ?>€</td>
                                    <td colspan="3" class="text-center">No hay variantes disponibles.</td>
                                    <td class="text-center">
                                        <a href="/modaurbana/admin/productos/editar.php?id=<?php echo $producto['id']; ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                        <a href="/modaurbana/admin/productos/eliminar_producto.php?id=<?php echo $producto['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este producto?');">Eliminar</a>
                                    </td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <!-- 
                Muestra un mensaje si no hay productos disponibles.
                -->
                <p>No hay productos disponibles.</p>
            <?php endif; ?>
        </div>
    </div>

</body>

</html>


<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>


<!-- 
Incluye el esqueleto del pie de la página.
-->
<?php include_once '../../includes/templates/footer.php'; ?>