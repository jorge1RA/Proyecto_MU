<?php

/**
 * mis_pedidos.php
 *
 * Página que muestra los pedidos del usuario actual.
 *
 * Muestra una lista de los pedidos realizados por el usuario, permitiendo ver los detalles de cada pedido.
 *
 * @category Usuario
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 * 
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto asegura que la información del usuario autenticado esté disponible durante la navegación.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Conecta la aplicación con la base de datos MySQL para acceder a la información de los pedidos.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si el usuario ha iniciado sesión.
 * 
 * Si no está autenticado, redirige al usuario a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Obtiene el ID del usuario actual desde la sesión.
 * 
 * @var int $usuario_id ID del usuario que inició sesión.
 */
$usuario_id = $_SESSION['usuario_id'];


/**
 * Prepara la consulta para obtener los pedidos del usuario actual.
 * 
 * Utiliza una declaración preparada para evitar inyecciones SQL y garantiza que la consulta solo devuelva los pedidos del usuario autenticado.
 * 
 * @var mysqli_stmt $stmt_pedidos Declaración preparada para obtener los pedidos del usuario.
 * @return mysqli_result $resultado_pedidos Resultado de la consulta de pedidos.
 */
$stmt_pedidos = $conexion->prepare("SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY fecha_pedido DESC");
$stmt_pedidos->bind_param("i", $usuario_id);
$stmt_pedidos->execute();
$resultado_pedidos = $stmt_pedidos->get_result();


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Añade la cabecera de la página, que incluye la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!-- 
Contenedor principal con margen superior.
-->
<div class="container mt-4">
    <h2>Mis Pedidos</h2>
    <!-- 
    Condición para verificar si el usuario tiene pedidos realizados.
    Si es mayor que cero, muestra los pedidos en una tabla.
    -->
    <?php if ($resultado_pedidos->num_rows > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Número de Pedido</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Método de Pago</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- 
                Bucle para generar una fila por cada pedido obtenido de la consulta.
                -->
                <?php while ($pedido = $resultado_pedidos->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pedido['id']); ?></td>
                        <td><?php echo htmlspecialchars($pedido['fecha_pedido']); ?></td>
                        <td><?php echo number_format($pedido['total'], 2); ?>€</td>
                        <td><?php echo ucfirst(htmlspecialchars($pedido['metodo_pago'])); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($pedido['estado'])); ?></td>
                        <td>
                            <a href="/modaurbana/admin/pedidos/ver_pedido.php?id=<?php echo urlencode($pedido['id']); ?>" class="btn btn-primary btn-sm">Ver Detalles</a>
                        </td>
                    </tr>
                    <!-- 
                    Fin del bucle de pedidos.
                    -->
                <?php endwhile; ?>
            </tbody>
        </table>
        <!-- 
        Si no hay pedidos, muestra un mensaje informativo.
        -->
    <?php else: ?>
        <p>No has realizado ningún pedido.</p>
    <?php endif; ?>

    <?php
    /**
     * Cierra el statement de la consulta de pedidos.
     * 
     * Esto libera los recursos asociados con la consulta.
     * 
     * @return void
     */
    $stmt_pedidos->close();
    ?>
</div>

<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
Incluye el esqueleto del pie de la página.
Añade la parte inferior de la página, que puede incluir enlaces y otros elementos de navegación.
-->
<?php include_once '../../includes/templates/footer.php'; ?>