<?php

/**
 * editar_estado.php
 * 
 * Página para editar el estado de un pedido específico.
 *
 * Permite al administrador actualizar el estado de un pedido seleccionado.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto asegura que la información del usuario autenticado esté disponible.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y tiene rol de administrador.
 * 
 * Si el usuario no tiene permisos, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite conectarme a la base de datos para leer y modificar información.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si se ha proporcionado un id de pedido válido en la URL.
 * 
 * Si no se ha proporcionado, redirijo al administrador al índice de administración.
 * 
 * @return void
 */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: /modaurbana/admin/index.php');
    exit();
}


/**
 * Obtiene y sanitiza el id del pedido.
 * 
 * Convierto el id del pedido a un entero para mayor seguridad y evitar ataques.
 * 
 * @var int $pedido_id ID del pedido.
 */
$pedido_id = intval($_GET['id']);


/**
 * Realiza una consulta para obtener los detalles del pedido.
 * 
 * Utilizo esta consulta para recuperar todos los datos del pedido en cuestión.
 * 
 * @var string $sql_pedido Consulta SQL para obtener el pedido.
 * @var mysqli_result|false $resultado_pedido Resultado de la consulta SQL.
 * @var array|false $pedido Los detalles del pedido en forma de arreglo asociativo.
 */
$sql_pedido = "SELECT * FROM pedidos WHERE id = '$pedido_id'";
$resultado_pedido = mysqli_query($conexion, $sql_pedido);
$pedido = mysqli_fetch_assoc($resultado_pedido);


/**
 * Verifica si el pedido existe.
 * 
 * Si no se encuentra el pedido, muestro un mensaje de error y detengo la ejecución del script.
 * 
 * @return void
 */
if (!$pedido) {
    echo "Pedido no encontrado.";
    exit();
}


/**
 * Procesa el formulario cuando se envía una actualización.
 * 
 * Si el método de solicitud es POST, significa que se está intentando actualizar el estado del pedido.
 * 
 * @return void
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    /**
     * Sanitiza el nuevo estado del pedido.
     * 
     * Utilizo mysqli_real_escape_string para evitar inyección SQL al actualizar el estado.
     * 
     * @var string $nuevo_estado El nuevo estado del pedido proporcionado por el formulario.
     */
    $nuevo_estado = mysqli_real_escape_string($conexion, $_POST['estado']);


    /**
     * Actualiza el estado del pedido en la base de datos.
     * 
     * Si la consulta se ejecuta correctamente, actualizo la variable $pedido con el nuevo estado y muestro un mensaje de éxito.
     * Si hay un error, muestro un mensaje de error.
     * 
     * @var string $sql_actualizar Consulta SQL para actualizar el estado del pedido.
     * @return void
     */
    $sql_actualizar = "UPDATE pedidos SET estado = '$nuevo_estado' WHERE id = '$pedido_id'";
    if (mysqli_query($conexion, $sql_actualizar)) {
        echo "<div class='alert alert-success'>Estado actualizado correctamente.</div>";


        /**
         * Actualiza el estado en la variable $pedido para reflejar el cambio en la interfaz.
         * 
         * @var string $pedido['estado'] Actualiza el estado del pedido actual en la variable local.
         */
        $pedido['estado'] = $nuevo_estado;
    } else {
        echo "<div class='alert alert-danger'>Error al actualizar el estado: " . mysqli_error($conexion) . "</div>";
    }
}

/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>


<!-- 
Contenedor principal con doble salto de línea para separar visualmente del resto del contenido.
-->
<br><br>
<h2>Editar Estado del Pedido #<?php echo htmlspecialchars($pedido['id']); ?></h2>
<br>
<!-- 
Formulario para actualizar el estado del pedido.
Envia los datos usando el método POST a la misma página.
-->
<form method="post" action="">
    <div class="form-group">
        <label for="estado">Estado Actual:</label>
        <select name="estado" id="estado" class="form-control">
            <option value="pendiente" <?php if ($pedido['estado'] == 'pendiente') echo 'selected'; ?>>Pendiente</option>
            <option value="procesando" <?php if ($pedido['estado'] == 'procesando') echo 'selected'; ?>>Procesando</option>
            <option value="enviado" <?php if ($pedido['estado'] == 'enviado') echo 'selected'; ?>>Enviado</option>
            <option value="entregado" <?php if ($pedido['estado'] == 'entregado') echo 'selected'; ?>>Entregado</option>
            <option value="cancelado" <?php if ($pedido['estado'] == 'cancelado') echo 'selected'; ?>>Cancelado</option>
        </select>
    </div>
    <br><br>
    <button type="submit" class="btn btn-primary">Actualizar Estado</button>
    <a href="index.php" class="btn btn-secondary">Volver a la lista de pedidos</a>
</form>

<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
Incluye el esqueleto del pie de la página.
Añade la parte inferior del sitio, incluyendo enlaces y otras secciones comunes.
-->
<?php include_once '../../includes/templates/footer.php'; ?>