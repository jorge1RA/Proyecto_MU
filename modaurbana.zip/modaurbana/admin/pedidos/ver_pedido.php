<?php

/**
 * ver_pedido.php
 *
 * Página que muestra los detalles de un pedido específico del usuario actual.
 *
 * Permite al usuario ver la información detallada de un pedido seleccionado.
 *
 * @category Usuario
 * @package  ModaUrbana
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 */
session_start();

/**
 * Verifica si el usuario está autenticado.
 */
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}

/**
 * Incluye el archivo de conexión a la base de datos.
 */
include_once '../../includes/conexion.php';

/**
 * Verifica si se ha proporcionado el id del pedido.
 */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: /modaurbana/admin/pedidos/mis_pedidos.php');
    exit();
}

/**
 * Obtiene y sanitiza el id del pedido y el id del usuario.
 */
$pedido_id = intval($_GET['id']);
$usuario_id = $_SESSION['usuario_id'];
$usuario_rol = $_SESSION['usuario_rol'];

/**
 * Prepara la consulta para obtener los detalles del pedido.
 */
if ($usuario_rol === 'admin') {
    // El administrador puede ver cualquier pedido
    $stmt_pedido = $conexion->prepare("
        SELECT p.*, u.nombre AS nombre_usuario, u.apellidos, u.email 
        FROM pedidos p
        INNER JOIN usuarios u ON p.usuario_id = u.id
        WHERE p.id = ?
    ");
    $stmt_pedido->bind_param("i", $pedido_id);
} else {
    // Los clientes solo pueden ver sus propios pedidos
    $stmt_pedido = $conexion->prepare("
        SELECT p.*, u.nombre AS nombre_usuario, u.apellidos, u.email 
        FROM pedidos p
        INNER JOIN usuarios u ON p.usuario_id = u.id
        WHERE p.id = ? AND p.usuario_id = ?
    ");
    $stmt_pedido->bind_param("ii", $pedido_id, $usuario_id);
}

/**
 * Ejecuta la consulta del pedido.
 */
$stmt_pedido->execute();
$resultado_pedido = $stmt_pedido->get_result();

/**
 * Verifica si se encontró el pedido.
 */
if ($resultado_pedido->num_rows === 0) {
    echo "Pedido no encontrado o no tienes permiso para verlo.";
    exit();
}

/**
 * Extrae los datos del pedido.
 */
$pedido = $resultado_pedido->fetch_assoc();

/**
 * Prepara la consulta para obtener los detalles de los productos incluidos en el pedido.
 */
$stmt_detalles = $conexion->prepare("
    SELECT dp.*, pr.nombre, pv.talla, pv.color, pr.precio AS precio_original
    FROM detalle_pedidos dp
    INNER JOIN productos pr ON dp.producto_id = pr.id
    LEFT JOIN producto_variantes pv ON dp.variante_id = pv.id
    WHERE dp.pedido_id = ?
");

/**
 * Verifica si la preparación de la consulta de detalles fue exitosa.
 */
if (!$stmt_detalles) {
    echo "Error al preparar la consulta de detalles: " . $conexion->error;
    exit();
}

/**
 * Vincula el id del pedido al parámetro de la consulta y ejecuta la consulta.
 */
$stmt_detalles->bind_param("i", $pedido_id);
$stmt_detalles->execute();
$resultado_detalles = $stmt_detalles->get_result();

/**
 * Incluye el esqueleto de la cabecera de la página.
 */
include_once '../../includes/templates/header.php';
?>

<!-- 
Contenedor principal con margen superior.
-->
<div class="container mt-4">
    <h2>Detalles del Pedido #<?php echo htmlspecialchars($pedido['id']); ?></h2>
    <!-- Información del pedido. -->
    <p><strong>Fecha:</strong> <?php echo htmlspecialchars($pedido['fecha_pedido']); ?></p>
    <p><strong>Cliente:</strong> <?php echo htmlspecialchars($pedido['nombre_usuario'] . ' ' . $pedido['apellidos']); ?></p>
    <p><strong>Total:</strong> <?php echo number_format($pedido['total'], 2); ?>€</p>
    <p><strong>Método de Pago:</strong> <?php echo ucfirst(htmlspecialchars($pedido['metodo_pago'])); ?></p>
    <p><strong>Dirección de Envío:</strong> <?php echo htmlspecialchars($pedido['direccion_envio']); ?></p>
    <p><strong>Estado:</strong> <?php echo ucfirst(htmlspecialchars($pedido['estado'])); ?></p>

    <!-- Sección de productos incluidos en el pedido. -->
    <h4>Productos</h4>
    <table class="table">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Talla</th>
                <th>Color</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <!-- Verifica si hay detalles del pedido para mostrar. -->
            <?php if ($resultado_detalles->num_rows > 0): ?>
                <!-- Bucle para generar una fila por cada producto del pedido. -->
                <?php while ($detalle = $resultado_detalles->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($detalle['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($detalle['talla'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($detalle['color'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($detalle['cantidad']); ?></td>
                        <td>
                            <?php
                            $precio_unitario = isset($detalle['precio_unitario']) ? floatval($detalle['precio_unitario']) : 0.0;
                            $precio_original = isset($detalle['precio_original']) ? floatval($detalle['precio_original']) : 0.0;

                            if ($precio_unitario < $precio_original) {
                                // Hay descuento
                                echo '<del>' . number_format($precio_original, 2) . '€</del><br>';
                                echo '<strong style="color:red;">' . number_format($precio_unitario, 2) . '€</strong>';
                            } else {
                                // Sin descuento
                                echo number_format($precio_unitario, 2) . '€';
                            }
                            ?>
                        </td>
                        <td><?php echo number_format($detalle['subtotal'], 2); ?>€</td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No hay productos en este pedido.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="/modaurbana/admin/pedidos/mis_pedidos.php" class="btn btn-secondary">Volver a Mis Pedidos</a>
</div>


<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
Incluye el esqueleto del pie de la página.
-->
<?php include_once '../../includes/templates/footer.php'; ?>