<?php

/**
 * index.php - pedidos
 * 
 * Página principal para la gestión de pedidos.
 *
 * Muestra una lista de todos los pedidos realizados, permitiendo al administrador
 * ver los detalles y editar el estado de cada pedido.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto asegura que la información del usuario autenticado esté disponible.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y tiene rol de administrador.
 * 
 * Si el usuario no tiene permisos, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite conectarme a la base de datos para leer y modificar información.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Realiza una consulta para obtener todos los pedidos junto con el nombre del usuario que los realizó.
 * 
 * Se utiliza un INNER JOIN para unir las tablas 'pedidos' y 'usuarios' a través del campo 'usuario_id'.
 * 
 * @var string $sql_pedidos Consulta SQL para obtener los pedidos.
 * @var mysqli_result|false $resultado_pedidos Resultado de la consulta SQL.
 */
$sql_pedidos = "SELECT p.*, u.nombre AS nombre_usuario FROM pedidos p
                INNER JOIN usuarios u ON p.usuario_id = u.id
                ORDER BY p.fecha_pedido DESC";


/**
 * Ejecuta la consulta en la base de datos y almacena el resultado en $resultado_pedidos.
 * 
 * @return void
 */
$resultado_pedidos = mysqli_query($conexion, $sql_pedidos);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>


<!-- 
Espacio en blanco para proporcionar separación visual.
-->
<br><br>
<h2>Gestión de Pedidos</h2>
<br>
<!-- 
Condición para verificar si hay pedidos disponibles.
Si hay uno o más pedidos, se muestran en una tabla.
-->
<?php if (mysqli_num_rows($resultado_pedidos) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Número de Pedido</th>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Total</th>
                <th>Método de Pago</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!-- 
            Bucle para generar una fila por cada pedido obtenido de la consulta.
            Para cada fila, se muestra la información del pedido, incluyendo id, fecha, usuario, total, método de pago y estado.
            -->
            <?php while ($pedido = mysqli_fetch_assoc($resultado_pedidos)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($pedido['id']); ?></td>
                    <td><?php echo htmlspecialchars($pedido['fecha_pedido']); ?></td>
                    <td><?php echo htmlspecialchars($pedido['nombre_usuario']); ?></td>
                    <td><?php echo htmlspecialchars(number_format($pedido['total'], 2)); ?>€</td>
                    <td><?php echo htmlspecialchars(ucfirst($pedido['metodo_pago'])); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($pedido['estado'])); ?></td>
                    <td>
                        <!--
                        Botones de acción para ver detalles y editar el estado del pedido.
                        -->
                        <a href="/modaurbana/admin/pedidos/ver_pedido.php?id=<?php echo $pedido['id']; ?>" class="btn btn-primary btn-sm">Ver Detalles</a>
                        <a href="/modaurbana/admin/pedidos/editar_estado.php?id=<?php echo $pedido['id']; ?>" class="btn btn-warning btn-sm">Editar Estado</a>
                    </td>
                </tr>
                <!-- 
                Fin del bucle de pedidos.
                -->
            <?php endwhile; ?>
        </tbody>
    </table>
    <!-- 
Si no hay pedidos, se muestra un mensaje informativo.
-->
<?php else: ?>
    <p>No hay pedidos registrados.</p>
<?php endif; ?>

<!-- 
Incluye el esqueleto del pie de la página.
Añade la parte inferior del sitio, incluyendo enlaces y otras secciones comunes.
-->
<?php include_once '../../includes/templates/footer.php'; ?>