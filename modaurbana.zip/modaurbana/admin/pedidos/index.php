<?php

/**
 * index.php - pedidos
 * 
 * Página principal para la gestión de pedidos.
 *
 * Muestra una lista de todos los pedidos realizados, permitiendo al administrador
 * ver los detalles y editar el estado de cada pedido.
 *
 * @category Administración
 * @package  ModaUrbana
 * @author   Jorge Romero
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 */
session_start();

/**
 * Verifica si el usuario está autenticado.
 * Si el usuario no está autenticado, lo redirige a la página de inicio de sesión.
 */
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}

/**
 * Incluye el archivo de conexión a la base de datos.
 */
include_once '../../includes/conexion.php';

/**
 * Realiza una consulta para obtener todos los pedidos junto con el nombre del usuario que los realizó.
 */
$sql_pedidos = "SELECT p.*, u.nombre AS nombre_usuario FROM pedidos p
                INNER JOIN usuarios u ON p.usuario_id = u.id
                ORDER BY p.fecha_pedido DESC";

/**
 * Ejecuta la consulta en la base de datos y almacena el resultado en $resultado_pedidos.
 */
$resultado_pedidos = mysqli_query($conexion, $sql_pedidos);

/**
 * Incluye el esqueleto de la cabecera de la página.
 */
include_once '../../includes/templates/header.php';
?>

<!-- Espacio en blanco para proporcionar separación visual -->
<br><br>
<h2>Gestión de Pedidos</h2>
<br><br>

<!-- Desplegable de pedidos alineado a la derecha -->
<!-- Uso "d-flex justify-content-end" para que el contenido se ubique en el extremo derecho del contenedor. -->
<div class="mb-4 d-flex justify-content-end">

    <!-- Con "width:auto; display:inline-block;" logro que el desplegable ocupe solo el espacio necesario y no toda la pantalla. -->
    <div style="width:auto; display:inline-block;">

        <!-- Este <select> es mi filtro de pedidos.
             Al cambiar la opción seleccionada (onchange="irAPedido()"), ejecuto la función irAPedido().
             Esa función desplazará la página hasta el pedido específico en la tabla, facilitando su localización. -->
        <select id="filtro-pedidos" class="form-control" onchange="irAPedido()">
            <!-- Opción inicial sin valor, para indicarle al administrador que seleccione un pedido. -->
            <option value="">-- Selecciona un pedido --</option>

            <?php
            // Reinicio el puntero de resultados para poder recorrer la lista de pedidos desde el principio.
            mysqli_data_seek($resultado_pedidos, 0);

            // Recorro cada pedido obtenido de la base de datos.
            // Por cada pedido, creo una opción en el desplegable.
            // El 'value' será el id del pedido, y el texto mostrará el número del pedido y el nombre del usuario.
            while ($pedido_opcion = mysqli_fetch_assoc($resultado_pedidos)) {
                echo '<option value="' . $pedido_opcion['id'] . '">Pedido #'
                    . $pedido_opcion['id'] . ' - '
                    . htmlspecialchars($pedido_opcion['nombre_usuario'])
                    . '</option>';
            }
            ?>
        </select>
    </div>
</div>


<!-- Condición para verificar si hay pedidos disponibles -->
<?php if (mysqli_num_rows($resultado_pedidos) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Número de Pedido</th>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Total</th>
                <th>Método de Pago</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!-- Reiniciamos el puntero de resultados antes de iterar -->
            <?php mysqli_data_seek($resultado_pedidos, 0); ?>
            <!-- Bucle para generar una fila por cada pedido -->
            <?php while ($pedido = mysqli_fetch_assoc($resultado_pedidos)): ?>
                <tr id="pedido-<?php echo $pedido['id']; ?>">
                    <td><?php echo htmlspecialchars($pedido['id']); ?></td>
                    <td><?php echo htmlspecialchars($pedido['fecha_pedido']); ?></td>
                    <td><?php echo htmlspecialchars($pedido['nombre_usuario']); ?></td>
                    <td><?php echo htmlspecialchars(number_format($pedido['total'], 2)); ?>€</td>
                    <td><?php echo htmlspecialchars(ucfirst($pedido['metodo_pago'])); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($pedido['estado'])); ?></td>
                    <td>
                        <!-- Botones de acción para ver detalles y editar el estado del pedido -->
                        <a href="/modaurbana/admin/pedidos/ver_pedido.php?id=<?php echo $pedido['id']; ?>" class="btn btn-primary btn-sm">Ver Detalles</a>
                        <a href="/modaurbana/admin/pedidos/editar_estado.php?id=<?php echo $pedido['id']; ?>" class="btn btn-warning btn-sm">Editar Estado</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <!-- Mensaje si no hay pedidos registrados -->
    <p>No hay pedidos registrados.</p>
<?php endif; ?>

<!-- Script para navegar al pedido seleccionado -->
<script>
    /**
     * Esta función se ejecuta en cuanto selecciono un pedido en el desplegable "filtro-pedidos".
     * Su objetivo es llevarme directamente a la fila que representa ese pedido en la tabla, sin que tenga que buscarlo a mano.
     * Además, resalta esa fila temporalmente para que la identifique fácilmente.
     */
    function irAPedido() {
        // Primero obtengo el elemento <select> que contiene la lista de pedidos.
        var select = document.getElementById('filtro-pedidos');

        // De este <select> obtengo el valor seleccionado, que corresponde al "id" del pedido.
        var pedidoId = select.value;

        // Verifico si realmente se ha seleccionado un pedido (es decir, si "pedidoId" no está vacío).
        if (pedidoId) {
            // Construyo el "id" del elemento <tr> en la tabla que muestra el pedido.
            // Suponemos que cada fila tiene un id tipo "pedido-<id_del_pedido>".
            var elementoPedido = document.getElementById('pedido-' + pedidoId);

            // Compruebo si el elemento correspondiente al pedido existe en la tabla.
            if (elementoPedido) {
                // Uso "scrollIntoView" para desplazar la pantalla hacia esa fila del pedido.
                // "behavior: 'smooth'" hace que el desplazamiento sea suave.
                // "block: 'center'" centra la fila en la ventana.
                elementoPedido.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });

                // Ahora resalto temporalmente la fila cambiando el color de fondo a amarillo (#ffff99).
                elementoPedido.style.backgroundColor = '#ffff99';

                // Después de 2 segundos (2000 milisegundos), quito el color de fondo para que la tabla vuelva a su estado normal.
                setTimeout(function() {
                    elementoPedido.style.backgroundColor = '';
                }, 2000);
            } else {
                // Si por algún motivo no encuentro la fila del pedido (por ejemplo, el pedido no está en la tabla),
                // muestro una alerta para avisarme.
                alert('Pedido no encontrado en la tabla.');
            }
        }
        // Si no se seleccionó ningún pedido (valor vacío), la función simplemente no hace nada.
    }
</script>


<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- Incluye el esqueleto del pie de la página -->
<?php include_once '../../includes/templates/footer.php'; ?>