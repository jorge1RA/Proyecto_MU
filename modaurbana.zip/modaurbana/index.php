<?php

/**
 * index.php - Principal (INICIO)
 * 
 * Página principal del sitio web ModaUrbana que muestra los productos destacados.
 * 
 * @category Inicio
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 * 
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 */
include_once 'includes/conexion.php';


/**
 * Consulta para obtener todos los productos disponibles en la base de datos.
 */
$sql = "SELECT * FROM productos";
$resultado = mysqli_query($conexion, $sql);


/**
 * Incluye el esqueleto de la cabecera de la página.
 */
include_once 'includes/templates/header.php';
?>

<!--  
Contenedor principal con margen superior.
-->
<div class="container-fluid mt-4">
    <br><br>
    <h2 class="mb-4 text-center">Productos Destacados</h2>
    <br><br>

    <!-- 
    Fila de productos. 
    -->
    <div class="row">
        <?php while ($producto = mysqli_fetch_assoc($resultado)) { ?>
            <!--
            Columna adaptable - Recordatorio de cada parte:
                - col-lg-3: Ocupa 25% del ancho en pantallas grandes.
                - col-md-6: Ocupa 50% del ancho en pantallas medianas.
                - col-sm-12: Ocupa 100% del ancho en pantallas pequeñas.
                - mb-4: Añade margen inferior para espaciar elementos.
            -->
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <div class="card h-100">

                    <?php if ($producto['imagen']): ?>
                        <!-- 
                        Envuelve la imagen en un enlace a producto.php pasando el id. 
                        -->
                        <a href="pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($producto['imagen']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" style="height: 300px; object-fit: cover;">
                        </a>

                    <?php else: ?>

                        <!-- 
                        Imagen de respaldo si no se encuentra la imagen del producto. 
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/" class="card-img-top" alt="Producto">
                        </a>
                    <?php endif; ?>

                    <!-- 
                    Cuerpo de la tarjeta. 
                    -->
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                    </div>

                    <!-- 
                    Pie de la tarjeta. 
                    -->
                    <div class="card-footer">
                        <p class="card-text"><?php echo number_format($producto['precio'], 2); ?>€</p>
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>" class="btn btn-primary">Comprar</a>
                    </div>

                </div>
            </div>
        <?php } ?>

    </div>
</div>

<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- 
Incluye el esqueleto del pie de la página. 
-->
<?php include_once 'includes/templates/footer.php'; ?>