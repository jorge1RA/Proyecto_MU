<?php

/**
 * index.php - Principal (INICIO)
 * 
 * Esta página muestra exclusivamente productos que están en oferta (es decir, con descuento > 0).
 * Ordeno estos productos por su descuento (de mayor a menor) y, en caso de igualdad, por su nombre.
 * Como resultado, solo veo los productos con algún descuento aplicado.
 */

/**
 * Inicio (o reanudo) la sesión para poder manejar datos del usuario si fuera necesario.
 */
session_start();

/**
 * Incluyo el archivo de conexión a la base de datos para poder hacer consultas.
 */
include_once 'includes/conexion.php';

/**
 * Aquí está la clave: realizo una consulta SQL que selecciona todos los productos 
 * cuya columna 'descuento' sea mayor que 0. Es decir, SOLO productos en oferta.
 * "WHERE descuento > 0" es la condición que filtra los productos.
 * 
 * También los ordeno por 'descuento' de forma descendente (los de mayor descuento primero),
 * y si empatan en descuento, los ordeno por 'nombre' en orden ascendente.
 */
$sql = "SELECT * FROM productos WHERE descuento > 0 ORDER BY descuento DESC, nombre ASC";
$resultado = mysqli_query($conexion, $sql);

/**
 * Incluyo la cabecera HTML (header) para mantener la estructura de la página.
 */
include_once 'includes/templates/header.php';
?>

<!--  
Aquí tengo un contenedor principal con un margen superior. Solo veré aquí los productos que cumplen la condición de descuento > 0.
-->
<div class="container-fluid mt-4">
    <br><br>
    <h2 class="mb-4 text-center">Productos destacados en Oferta</h2>
    <br><br>

    <!-- 
    En esta sección, coloco los productos en una cuadrícula (row).
    Cada producto se mostrará en una tarjeta (card).
    -->
    <div class="row">
        <?php
        // Recorro uno a uno los productos que ha devuelto la consulta.
        // Todos estos productos ya tienen descuento > 0 gracias a la condición del SQL.
        while ($producto = mysqli_fetch_assoc($resultado)) { ?>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <div class="card h-100">

                    <?php if ($producto['imagen']): ?>
                        <!-- 
                        Si el producto tiene imagen, la muestro.
                        style="height: 300px; object-fit: cover;" para asegurar que se vea bien recortada y no deformada.
                        Al hacer clic en la imagen, voy a la página de detalles del producto.
                        -->
                        <a href="pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($producto['imagen']); ?>"
                                class="card-img-top"
                                alt="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                style="height: 300px; object-fit: cover;">
                        </a>
                    <?php else: ?>
                        <!-- 
                        Si no hay imagen disponible, uso una imagen por defecto.
                        Aun así, el enlace me lleva a la página de detalles del producto.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/" class="card-img-top" alt="Producto">
                        </a>
                    <?php endif; ?>

                    <!-- 
                    Cuerpo de la tarjeta:
                    Como todos los productos aquí tienen descuento > 0, no necesito condicional para "OFERTA", pero igual se coloca la etiqueta.
                    Muestro el nombre y descripción del producto.
                    -->
                    <div class="card-body">
                        <h3 class="oferta text-danger font-weight-bold mb-1 text-center">OFERTA</h3>
                        <br>
                        <h5 class="card-title text-center font-weight-bold"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                        <p class="card-text text-muted text-center"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                    </div>

                    <!-- 
                    Pie de la tarjeta:
                    Calculo el precio con descuento.
                    Ya sé que descuento > 0, así que siempre habrá un precio rebajado que mostrar.
                    Muestro el precio original tachado y el nuevo precio en grande y resaltado.
                    -->
                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <div class="text-left">
                            <?php
                            // Calculo el precio con el descuento aplicado
                            $precio_descuento = $producto['precio'] - ($producto['precio'] * $producto['descuento'] / 100);
                            ?>
                            <p class="text-dark font-weight-bold mb-1">
                                <!-- 
                                Precios: 
                                - Primero el original tachado,
                                - Luego el porcentaje de descuento,
                                - Finalmente, abajo el precio con descuento.
                                -->
                                <del><?php echo number_format($producto['precio'], 2); ?>€</del>
                                <span class="text-danger ml-2">-<?php echo number_format($producto['descuento'], 0); ?>%</span>
                            </p>
                            <p class="precio-con-descuento text-danger font-weight-bold h4 mb-1">
                                <?php echo number_format($precio_descuento, 2); ?>€
                            </p>
                        </div>
                        <div class="text-right">
                            <!-- Botón "Comprar" que lleva a la página de detalles del producto. -->
                            <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>" class="btn btn-primary">Comprar</a>
                        </div>
                    </div>

                </div>
            </div>
        <?php } ?>
    </div>
</div>

<!-- 
INFO:
En este código, la parte que hace que solo se vean productos con oferta es la consulta SQL inicial:
"SELECT * FROM productos WHERE descuento > 0..."
Esto asegura que solo se obtengan productos cuyo campo 'descuento' es mayor que 0, 
y por ende, en la página se muestran únicamente los artículos en oferta.
-->

<!-- Enlace a Google Fonts para aplicar las tipografías Montserrat y Playfair Display -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- 
Incluyo el pie de la página, que contiene información común como enlaces u otra sección.
-->
<?php include_once 'includes/templates/footer.php'; ?>