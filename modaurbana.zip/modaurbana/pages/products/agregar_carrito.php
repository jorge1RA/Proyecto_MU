<?php

/**
 * agregar_carrito.php
 * 
 * Añade un producto al carrito de compras.
 * Se verifican las variantes y el stock disponible antes de agregar o actualizar la cantidad en el carrito.
 * 
 * @category Carrito
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Utilizo esta función para asegurar que los datos del carrito se mantengan consistentes para el usuario actual.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto permite realizar consultas necesarias para verificar los detalles del producto.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si la solicitud es POST.
 * 
 * Si no es una solicitud POST, redirijo al usuario a la tienda para evitar accesos no válidos.
 * 
 * @return void
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /**
     * Obtiene y sanitiza los datos del formulario.
     * 
     * Obtengo los detalles del producto como id, talla, color y cantidad para realizar las validaciones necesarias.
     */
    $producto_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $talla = isset($_POST['talla']) ? trim($_POST['talla']) : '';
    $color = isset($_POST['color']) ? trim($_POST['color']) : '';
    $cantidad = isset($_POST['cantidad']) ? intval($_POST['cantidad']) : 1;


    /**
     * Valida que el id del producto es válido.
     * 
     * Si el id del producto no es válido, redirijo al usuario con un mensaje de error.
     */
    if ($producto_id <= 0) {
        $_SESSION['error'] = "ID de producto inválido.";
        header('Location: /modaurbana/pages/products/tienda.php');
        exit();
    }

    /**
     * Obtiene los detalles del producto desde la base de datos.
     * 
     * Realizo una consulta para verificar si el producto existe y obtener sus detalles.
     */
    $stmt = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $producto = $resultado->fetch_assoc();
    $stmt->close();


    /**
     * Verifica si el producto fue encontrado.
     * 
     * Si no se encuentra el producto, muestro un mensaje de error y redirijo.
     */
    if (!$producto) {
        $_SESSION['error'] = "Producto no encontrado.";
        header('Location: /modaurbana/pages/products/tienda.php');
        exit();
    }


    /**
     * Verifica si la cantidad solicitada excede el stock disponible.
     * 
     * Si el stock es insuficiente, muestro un mensaje de error.
     */
    if ($cantidad > intval($producto['stock'])) {
        $_SESSION['error'] = "La cantidad solicitada excede el stock disponible.";
        header('Location: /modaurbana/pages/products/productos.php?id=' . $producto_id);
        exit();
    }


    /**
     * Valida la selección de la talla si existen tallas disponibles.
     * 
     * Si hay tallas y no se selecciona una, muestro un error.
     */
    if (!empty($producto['tallas'])) {
        if (empty($talla)) {
            $_SESSION['error'] = "Por favor, selecciona una talla.";
            header('Location: /modaurbana/pages/products/productos.php?id=' . $producto_id);
            exit();
        }

        /**
         * Valida que la talla seleccionada es válida.
         * 
         * Si la talla seleccionada no está entre las opciones disponibles, muestro un error.
         */
        $tallas_disponibles = array_map('trim', explode(',', $producto['tallas']));
        if (!in_array($talla, $tallas_disponibles)) {
            $_SESSION['error'] = "Talla inválida seleccionada.";
            header('Location: /modaurbana/pages/products/productos.php?id=' . $producto_id);
            exit();
        }
    } else {
        /**
         * Asigna un valor predeterminado si no hay tallas disponibles.
         */
        $talla = 'N/A';
    }


    /**
     * Valida la selección del color si existen colores disponibles.
     * 
     * Si hay colores y no se selecciona uno, muestro un error.
     */
    if (!empty($producto['colores'])) {
        if (empty($color)) {
            $_SESSION['error'] = "Por favor, selecciona un color.";
            header('Location: /modaurbana/pages/products/productos.php?id=' . $producto_id);
            exit();
        }


        /**
         * Valida que el color seleccionado es válido.
         * 
         * Si el color seleccionado no está entre las opciones disponibles, muestro un error.
         */
        $colores_disponibles = array_map('trim', explode(',', $producto['colores']));
        if (!in_array($color, $colores_disponibles)) {
            $_SESSION['error'] = "Color inválido seleccionado.";
            header('Location: /modaurbana/pages/products/productos.php?id=' . $producto_id);
            exit();
        }
    } else {
        /**
         * Asigna un valor predeterminado si no hay colores disponibles.
         */
        $color = 'N/A';
    }

    /**
     * Crea una clave única para identificar el producto con sus variantes.
     * 
     * Esta clave me permite identificar un producto en el carrito de acuerdo con sus variantes de talla y color.
     */
    $clave = $producto_id;

    if (!empty($producto['tallas']) && !empty($producto['colores'])) {
        $clave .= '_' . $talla . '_' . $color;
    } elseif (!empty($producto['tallas'])) {
        $clave .= '_' . $talla;
    } elseif (!empty($producto['colores'])) {
        $clave .= '_' . $color;
    } else {
        $clave .= '_N/A';
    }

    /**
     * Inicializa el carrito si no existe.
     * 
     * Utiliza una sesión para almacenar los productos que el usuario agrega al carrito.
     */
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    /**
     * Si el producto con la misma variante ya está en el carrito, actualiza la cantidad,
     * de lo contrario, añade el producto al carrito.
     */
    if (isset($_SESSION['carrito'][$clave])) {
        $nueva_cantidad = $_SESSION['carrito'][$clave]['cantidad'] + $cantidad;
        if ($nueva_cantidad > intval($producto['stock'])) {
            $_SESSION['error'] = "La cantidad total en el carrito excede el stock disponible.";
        } else {
            $_SESSION['carrito'][$clave]['cantidad'] = $nueva_cantidad;
            $_SESSION['success'] = "Cantidad actualizada en el carrito.";
        }
    } else {
        /**
         * Añade el producto al carrito.
         */
        $_SESSION['carrito'][$clave] = [
            'id' => $producto['id'],
            'nombre' => $producto['nombre'],
            'precio' => $producto['precio'],
            'talla' => $talla,
            'color' => $color,
            'cantidad' => $cantidad,
            'imagen' => $producto['imagen']
        ];
        $_SESSION['success'] = "Producto añadido al carrito.";
    }

    /**
     * Redirige al carrito después de la operación.
     * 
     * Tras agregar o actualizar un producto en el carrito, redirijo al usuario a la página del carrito.
     */
    header('Location: /modaurbana/pages/cart/carrito.php');
    exit();
} else {
    /**
     * Si no es una solicitud POST, redirige al inicio de la tienda.
     * 
     * Si alguien intenta acceder a esta página sin utilizar un método POST, lo redirijo a la tienda.
     */
    header('Location: /modaurbana/pages/products/tienda.php');
    exit();
}
