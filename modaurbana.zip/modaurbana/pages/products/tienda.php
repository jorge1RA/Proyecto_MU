<?php

/**
 * tienda.php
 * 
 * Página principal de la tienda donde se muestran todos los productos disponibles.
 * Permite filtrar los productos por categoría y muestra los descuentos si aplican.
 * 
 * @category Productos
 * @package  ModaUrbana
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 */
session_start();

/**
 * Incluye el archivo de conexión a la base de datos.
 */
include_once '../../includes/conexion.php';

/**
 * Obtiene las categorías únicas disponibles en la base de datos.
 */
$sql_categorias = "SELECT DISTINCT categoria FROM productos";
$resultado_categorias = mysqli_query($conexion, $sql_categorias);

/**
 * Obtiene los productos, filtrados opcionalmente por categoría y ordenados por descuento.
 */
$categoria_seleccionada = isset($_GET['categoria']) ? $_GET['categoria'] : '';

if ($categoria_seleccionada) {
    /**
     * Sanitiza la entrada de categoría para prevenir inyecciones SQL.
     */
    $categoria_seleccionada = mysqli_real_escape_string($conexion, $categoria_seleccionada);
    $sql_productos = "SELECT * FROM productos WHERE categoria='$categoria_seleccionada' ORDER BY descuento DESC, nombre ASC";
} else {
    /**
     * Si no se selecciona una categoría específica, muestra todos los productos ordenados por descuento.
     */
    $sql_productos = "SELECT * FROM productos ORDER BY descuento DESC, nombre ASC";
}

/**
 * Ejecuta la consulta SQL para obtener los productos.
 */
$resultado_productos = mysqli_query($conexion, $sql_productos);

/**
 * Incluye el esqueleto de la cabecera de la página.
 */
include_once '../../includes/templates/header.php';
?>

<!--  
Contenedor Principal,
permitiendo mostrar la interfaz principal de la tienda y sus productos.
-->
<div class="container-fluid mt-4">
    <br>
    <h2 class="mb-4 text-center">Nuestra Tienda</h2>
    <br>

    <!-- Filtro de Categorías -->
    <div class="mb-4 text-center">
        <!-- Botón para desplegar los filtros, solo con texto -->
        <button id="filtroBoton" class="btn btn-secondary mb-3" onclick="toggleFiltros()">
            Filtrar y Ordenar
        </button>

        <!-- Contenedor de los botones de categoría que se mostrará/ocultará -->
        <div id="filtrosCategoria" class="mb-4 text-center" style="display: none;">
            <a href="/modaurbana/pages/products/tienda.php" class="btn btn-secondary mx-1">Todas</a>
            <?php while ($categoria = mysqli_fetch_assoc($resultado_categorias)): ?>
                <a href="/modaurbana/pages/products/tienda.php?categoria=<?php echo urlencode($categoria['categoria']); ?>" class="btn btn-secondary mx-1">
                    <?php echo ucfirst(htmlspecialchars($categoria['categoria'])); ?>
                </a>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- 
    Lista de Productos: 
    Muestra todos los productos que cumplen con el filtro de categoría (si se ha seleccionado alguno).
    -->
    <!-- Este contenedor "row" me permite mostrar productos en varias columnas, adaptándose al tamaño de pantalla -->
    <div class="row">
        <?php
        // Mientras haya productos en $resultado_productos, voy generando una tarjeta por cada uno,
        // cada iteración produce un "div" con la info del producto.
        while ($producto = mysqli_fetch_assoc($resultado_productos)) { ?>
            <!-- 
            RECORDATORIO:
            -------------
            col-lg-3: En pantallas grandes, ocupa 3 columnas (1/4 del ancho).
            col-md-6: En pantallas medianas, 2 columnas (mitad de ancho).
            col-sm-12: En pantallas pequeñas, 1 columna (ancho completo).
            mb-4: Añade margen inferior para espaciar las tarjetas.
            -->
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <!-- "card h-100": Crea una tarjeta con altura completa, para mantener uniformidad entre tarjetas -->
                <div class="card h-100">

                    <?php if ($producto['imagen']): ?>
                        <!-- 
                        Si el producto tiene imagen, la muestro dentro de un enlace que lleva a la página de detalles del producto,
                        style="height: 300px; object-fit: cover;": Ajusta la imagen para que se vea bien recortada sin deformarse.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($producto['imagen']); ?>"
                                class="card-img-top"
                                alt="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                style="height: 300px; object-fit: cover;">
                        </a>
                    <?php else: ?>
                        <!-- 
                        Si no hay imagen, uso una por defecto,
                        También enlazo a la página de detalles.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/" class="card-img-top" alt="Producto">
                        </a>
                    <?php endif; ?>

                    <!-- 
                    Cuerpo de la tarjeta:
                    Aquí muestro si el producto está en oferta, su nombre y descripción.
                    -->
                    <div class="card-body">
                        <?php if ($producto['descuento'] > 0): ?>
                            <!-- "OFERTA" en texto grande y en rojo si el producto tiene descuento -->
                            <h3 class="oferta text-danger font-weight-bold mb-1 text-center">OFERTA</h3>
                        <?php endif; ?>
                        <br>
                        <!-- Título del producto en negrita y centrado -->
                        <h5 class="card-title text-center font-weight-bold">
                            <?php echo htmlspecialchars($producto['nombre']); ?>
                        </h5>
                        <!-- Descripción del producto, en texto más suave (text-muted) y centrado -->
                        <p class="card-text text-muted text-center">
                            <?php echo htmlspecialchars($producto['descripcion']); ?>
                        </p>
                    </div>

                    <!-- 
                    Pie de la tarjeta:
                    Muestra el precio, con o sin descuento, y el botón "Comprar".
                    "d-flex justify-content-between align-items-center": distribución horizontal,
                    con el precio a la izquierda y el botón a la derecha.
                    -->
                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <div class="text-left">
                            <?php if ($producto['descuento'] > 0): ?>
                                <?php
                                // Calculo el precio con descuento
                                $precio_descuento = $producto['precio'] - ($producto['precio'] * $producto['descuento'] / 100);
                                ?>
                                <!-- 
                                Precio original tachado en rojo
                                -->
                                <p class="precio-original text-danger font-weight-bold mb-1">
                                    <del><?php echo number_format($producto['precio'], 2); ?>€</del>
                                </p>
                                <!-- 
                                Precio con descuento, en texto oscuro, más grande (h4) y negrita,
                                para darle más importancia visual.
                                -->
                                <p class="precio-con-descuento text-dark font-weight-bold h4 mb-1">
                                    <?php echo number_format($precio_descuento, 2); ?>€
                                </p>
                            <?php else: ?>
                                <!-- Si no hay descuento, muestro el precio normal en h5 y negrita -->
                                <p class="precio h5 font-weight-bold mb-1">
                                    <?php echo number_format($producto['precio'], 2); ?>€
                                </p>
                            <?php endif; ?>
                        </div>

                        <div class="text-right">
                            <!-- 
                            Botón "Comprar" que lleva a la página de detalles del producto, donde el usuario podrá añadirlo al carrito.
                            -->
                            <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>" class="btn btn-primary">Comprar</a>
                        </div>
                    </div>

                </div> <!-- Fin de .card -->
            </div> <!-- Fin de .col-* -->
        <?php } ?> <!-- Fin del bucle while -->
    </div> <!-- Fin de .row -->

</div>

<!-- 
Script para alternar la visibilidad de los filtros de categoría 
-->
<script>
    function toggleFiltros() {
        var filtros = document.getElementById('filtrosCategoria');
        if (filtros.style.display === 'none' || filtros.style.display === '') {
            filtros.style.display = 'block';
        } else {
            filtros.style.display = 'none';
        }
    }
</script>

<!-- Enlace a Google Fonts para aplicar las tipografías Montserrat y Playfair Display en el diseño -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- 
Incluye el esqueleto del pie de la página. 
-->
<?php include_once '../../includes/templates/footer.php'; ?>