<?php

/**
 * tienda.php
 * 
 * Página principal de la tienda donde se muestran todos los productos disponibles.
 * Permite filtrar los productos por categoría.
 * 
 * @category Productos
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Utilizo esta función para manejar la información del usuario a lo largo de la sesión.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite acceder a los datos de los productos y categorías desde la base de datos.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Obtiene las categorías únicas disponibles en la base de datos.
 * 
 * Utilizo una consulta SQL para extraer las categorías de los productos, de modo que pueda ofrecer filtros en la tienda.
 * 
 * @var mysqli_result|false $resultado_categorias El resultado de la consulta SQL para obtener las categorías.
 */
$sql_categorias = "SELECT DISTINCT categoria FROM productos";
$resultado_categorias = mysqli_query($conexion, $sql_categorias);

/**
 * Obtiene los productos, filtrados opcionalmente por categoría.
 * 
 * Verifico si el usuario ha seleccionado una categoría específica.
 */
$categoria_seleccionada = isset($_GET['categoria']) ? $_GET['categoria'] : '';


if ($categoria_seleccionada) {
    /**
     * Sanitiza la entrada de categoría para prevenir inyecciones SQL.
     * 
     * Me aseguro de que el valor de la categoría sea seguro para usar en la consulta SQL.
     */
    $categoria_seleccionada = mysqli_real_escape_string($conexion, $categoria_seleccionada);
    $sql_productos = "SELECT * FROM productos WHERE categoria='$categoria_seleccionada'";
} else {
    /**
     * Si no se selecciona una categoría específica, muestra todos los productos.
     */
    $sql_productos = "SELECT * FROM productos";
}


/**
 * Ejecuta la consulta SQL para obtener los productos.
 * 
 * Esto me permite mostrar la lista de productos en la página de la tienda.
 * 
 * @var mysqli_result|false $resultado_productos El resultado de la consulta SQL para obtener los productos.
 */
$resultado_productos = mysqli_query($conexion, $sql_productos);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!--  
Contenedor Principal,
permitiendo mostrar la interfaz principal de la tienda y sus productos.
-->
<div class="container mt-4">
    <h2 class="mb-4">Nuestra Tienda</h2>

    <!-- 
    Filtro de Categorías, 
    donde proporciono botones para filtrar los productos según su categoría.
    -->
    <div class="mb-4">

        <!-- 
        Botón para mostrar todos los productos: 
        Este botón resetea el filtro de categorías y muestra todos los productos disponibles.
        -->
        <a href="/modaurbana/pages/products/tienda.php" class="btn btn-secondary">Todas</a>

        <!-- 
        Botones de filtro por cada categoría disponible: 
        Creo un botón por cada categoría recuperada de la base de datos.
        -->
        <?php while ($categoria = mysqli_fetch_assoc($resultado_categorias)): ?>
            <a href="/modaurbana/pages/products/tienda.php?categoria=<?php echo urlencode($categoria['categoria']); ?>" class="btn btn-secondary">
                <?php echo ucfirst(htmlspecialchars($categoria['categoria'])); ?>
            </a>
        <?php endwhile; ?>
    </div>

    <!-- 
    Lista de Productos: 
    Muestra todos los productos que cumplen con el filtro de categoría (si sea seleccionado alguno).
    -->
    <div class="row">
        <?php while ($producto = mysqli_fetch_assoc($resultado_productos)) { ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <?php if ($producto['imagen']): ?>

                        <!-- 
                        Enlace con imagen del producto para redirigir a la página de detalles. 
                        Esto permite a los usuarios hacer clic en la imagen para ver más detalles del producto.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($producto['imagen']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" style="height: 300px; object-fit: cover;">
                        </a>

                    <?php else: ?>
                        <!-- 
                        Imagen por defecto si no hay imagen disponible. 
                        Esto garantiza que siempre haya una imagen visible para el producto.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>">
                            <img src="/modaurbana/assets/img/" class="card-img-top" alt="Producto">
                        </a>
                    <?php endif; ?>

                    <div class="card-body">
                        <!-- 
                        Nombre del producto: 
                        Muestra el nombre del producto de forma destacada.
                        -->
                        <h5 class="card-title"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                        <!-- 
                        Descripción del producto: 
                        Proporciono una breve descripción del producto.
                        -->
                        <p class="card-text"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                    </div>

                    <div class="card-footer">
                        <!-- 
                        Precio del producto: 
                        Muestra el precio del producto.
                        -->
                        <p class="card-text"><?php echo number_format($producto['precio'], 2); ?>€</p>
                        <!-- 
                        Cambia el enlace para redirigir a producto.php en lugar de agregar directamente al carrito. 
                        Esto permite al usuario ver más detalles del producto antes de añadirlo al carrito.
                        -->
                        <a href="/modaurbana/pages/products/productos.php?id=<?php echo intval($producto['id']); ?>" class="btn btn-primary">Comprar</a>

                    </div>
                </div>
            </div>
        <?php } ?>

    </div>
</div>

<!-- 
Incluye el esqueleto del pie de la página. 
Esto añade el pie de página con la información adicional del sitio.
-->
<?php include_once '../../includes/templates/footer.php'; ?>