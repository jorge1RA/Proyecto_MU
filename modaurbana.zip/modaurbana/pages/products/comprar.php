<?php

/**
 * comprar.php
 * 
 * Página para realizar la compra de un producto.
 * Muestra la información del producto que el usuario ha seleccionado para comprar.
 * 
 * @category Compra
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Utilizo esta función para asegurar que el usuario esté autenticado antes de continuar con la compra.
 * 
 * @return void
 */
session_start();


/**
 * Verifica si el usuario está autenticado y si tiene el rol de administrador.
 * 
 * Si el usuario no cumple con estas condiciones, lo redirijo a la página de inicio de sesión.
 * 
 * @return void
 */
if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] != 'admin') {
    header('Location: /modaurbana/pages/login/login.php');
    exit();
}


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto permite realizar consultas necesarias para obtener la información del producto.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si se ha proporcionado un id de producto.
 * 
 * Si no se proporciona un id, muestro un mensaje de error indicando que no se ha seleccionado un producto.
 */
if (isset($_GET['id'])) {
    $producto_id = $_GET['id'];

    /**
     * Obtiene la información del producto desde la base de datos.
     * 
     * Realizo una consulta para obtener los detalles del producto seleccionado.
     * 
     * @var string $sql La consulta SQL para obtener el producto.
     * @var mysqli_result|false $resultado El resultado de ejecutar la consulta SQL en la base de datos.
     */
    $sql = "SELECT * FROM productos WHERE id='$producto_id'";
    $resultado = mysqli_query($conexion, $sql);
    $producto = mysqli_fetch_assoc($resultado);


    /**
     * Verifica si el producto fue encontrado.
     * 
     * Si se encuentra el producto, muestro el nombre y precio del mismo.
     */
    if ($producto) {
        /**
         * Muestra el nombre y precio del producto seleccionado para comprar.
         * 
         * Utilizo `echo` para mostrar la información del producto.
         */
        echo "<h2>Has comprado: " . htmlspecialchars($producto['nombre']) . "</h2>";
        echo "<p>Precio: €" . number_format($producto['precio'], 2) . "</p>";
        echo "<a href='index.php'>Volver a la tienda</a>";
    } else {
        /**
         * Mensaje de error si el producto no fue encontrado en la base de datos.
         */
        echo "Producto no encontrado.";
    }
} else {
    /**
     * Mensaje de error si no se ha proporcionado un ID de producto.
     * 
     * Esto indica al usuario que no se ha seleccionado ningún producto para comprar.
     */
    echo "No se ha seleccionado ningún producto.";
}
