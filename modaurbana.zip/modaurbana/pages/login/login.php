<?php

/**
 * login.php
 * 
 * Página de inicio de sesión para los usuarios de ModaUrbana.
 * Permite autenticar a los usuarios y redirigirlos según su rol (usuario o administrador).
 * 
 * @category Autenticación
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Uso esta función para asegurar que cualquier intento de iniciar sesión 
 * tenga la información de sesión correctamente configurada.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto permite acceder a la base de datos para verificar las credenciales de los usuarios.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Procesa el formulario de inicio de sesión cuando se envía una solicitud POST.
 * 
 * Aquí verifico que la solicitud sea POST para asegurar que los datos provienen del formulario.
 * Si es así, proceso los datos enviados para verificar las credenciales.
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    /**
     * Obtiene y sanitiza el correo electrónico y la contraseña para evitar inyección SQL.
     * 
     * @var string $email Correo electrónico ingresado por el usuario.
     * @var string $password Contraseña ingresada por el usuario.
     */
    $email = $_POST['email'];
    $password = $_POST['password'];

    /**
     * Sanitiza el correo electrónico utilizando `mysqli_real_escape_string` para prevenir inyecciones SQL.
     */
    $email = mysqli_real_escape_string($conexion, $email);


    /**
     * Consulta para obtener el usuario por su correo electrónico.
     * 
     * @var string $sql Consulta SQL para buscar al usuario por su correo.
     * @var mysqli_result|false $resultado Resultado de la ejecución de la consulta.
     */
    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $resultado = mysqli_query($conexion, $sql);
    $usuario = mysqli_fetch_assoc($resultado);

    /**
     * Verifica si el usuario existe y si la contraseña ingresada es correcta.
     * 
     * Utilizo `password_verify` para comparar la contraseña ingresada con la contraseña hasheada almacenada.
     */
    if ($usuario && password_verify($password, $usuario['password'])) {
        /**
         * Guarda la información del usuario en la sesión.
         * 
         * Almaceno el `id`, `nombre` y `rol` del usuario para gestionar su autenticación y acceso a las páginas según el rol.
         */
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nombre'] = $usuario['nombre'];
        $_SESSION['usuario_rol'] = $usuario['rol'];

        /**
         * Redirige al panel correspondiente según el rol del usuario.
         * 
         * Si es administrador, se redirige al panel de administración.
         * De lo contrario, se redirige al perfil del usuario.
         */
        if ($usuario['rol'] == 'admin') {
            header('Location: /modaurbana/admin/index.php');
        } else {
            header('Location: /modaurbana/admin/perfil/perfil.php');
        }
        exit();
    } else {
        /**
         * Mensaje de error si las credenciales no son correctas.
         * 
         * Si la combinación de correo y contraseña no es válida, muestro un mensaje de error.
         */
        $error = "Correo o contraseña incorrectos.";
    }
}


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>

    <!--  
    Contenedor Principal.
    Este contenedor muestra el formulario para que el usuario pueda iniciar sesión.
    -->
    <div class="background-container">
        <div class="container">
            <br><br>
            <h2 data-aos="fade-up">Iniciar Sesión</h2>
            <br>
            <!-- 
            Mostrar mensaje de error si las credenciales no son correctas.
            -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- 
            Formulario de inicio de sesión.
            Permite a los usuarios ingresar su correo electrónico y contraseña para acceder.
            -->
            <form method="POST" action="/modaurbana/pages/login/login.php">

                <div class="form-group">
                    <label><strong>Correo electrónico</strong></label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label><strong>Contraseña</strong></label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary">Ingresar</button>
            </form>
        </div>
    </div>

    <!-- Incluye el CSS de AOS para añadir estilos de animación -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


    <!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

    <!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
    <script>
        AOS.init();
    </script>


</body>

</html>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade el pie de página, que incluye información adicional del sitio web.
-->
<?php include_once '../../includes/templates/footer.php'; ?>