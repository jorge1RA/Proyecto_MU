<?php

/**
 * logout.php
 * 
 * Página para cerrar la sesión del usuario.
 * Destruye la sesión actual y redirige al usuario a la página de inicio.
 * 
 * @category Autenticación
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia la sesión para poder manipularla.
 * 
 * Esto me permite acceder a los datos de la sesión que quiero eliminar.
 * 
 * @return void
 */
session_start();


/**
 * Elimina todas las variables de sesión.
 * 
 * Uso `session_unset()` para asegurarme de que todas las variables de sesión actuales sean eliminadas.
 * 
 * @return void
 */
session_unset();


/**
 * Destruye la sesión.
 * 
 * Esto cierra la sesión actual completamente y elimina todos los datos asociados con ella.
 * 
 * @return void
 */
session_destroy();


/**
 * Redirige al usuario a la página de inicio.
 * 
 * Luego de destruir la sesión, redirijo al usuario a la página principal del sitio.
 * 
 * @return void
 */
header("Location: /modaurbana/index.php");
exit();
