<?php

/**
 * confirmacion.php
 * 
 * Página de confirmación del pedido realizado.
 * Muestra los detalles del pedido que el usuario acaba de completar.
 * 
 * @category Confirmación
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Uso esta función para asegurar que el usuario esté autenticado antes de acceder a la página de confirmación del pedido.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite conectarme a la base de datos para obtener la información del pedido y sus detalles.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Verifica si el id del pedido está disponible, de lo contrario redirige al inicio.
 * 
 * Si no se proporciona un id de pedido en la URL, redirijo al usuario a la página de inicio.
 * 
 * @return void
 */
if (!isset($_GET['pedido_id'])) {
    header('Location: index.php');
    exit();
}

/**
 * Obtiene el id del pedido.
 * 
 * Uso la variable $_GET para recuperar el ID del pedido de la URL.
 * 
 * @var int $pedido_id ID del pedido
 */
$pedido_id = $_GET['pedido_id'];


/**
 * Obtiene la información del pedido de la base de datos.
 * 
 * Realizo una consulta para recuperar los datos del pedido correspondiente al id proporcionado.
 * 
 * @var string $sql_pedido La consulta SQL para obtener los datos del pedido.
 * @var mysqli_result|false $resultado_pedido El resultado de la ejecución de la consulta SQL.
 * @var array $pedido Los datos del pedido como un array asociativo.
 */
$sql_pedido = "SELECT * FROM pedidos WHERE id='$pedido_id'";
$resultado_pedido = mysqli_query($conexion, $sql_pedido);
$pedido = mysqli_fetch_assoc($resultado_pedido);


/**
 * Obtiene los detalles del pedido, incluyendo el nombre del producto.
 * 
 * Realizo una consulta para recuperar los detalles del pedido, como los productos incluidos y sus cantidades.
 * 
 * @var string $sql_detalles La consulta SQL para obtener los detalles del pedido.
 * @var mysqli_result|false $resultado_detalles El resultado de la ejecución de la consulta SQL.
 */
$sql_detalles = "SELECT dp.*, p.nombre FROM detalle_pedidos dp INNER JOIN productos p ON dp.producto_id = p.id WHERE dp.pedido_id='$pedido_id'";
$resultado_detalles = mysqli_query($conexion, $sql_detalles);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!--  
Contenedor Principal.
Este contenedor me permite mostrar al usuario los detalles del pedido que acaba de completar.
-->
<div class="container mt-4">
    <h2>Pedido Realizado</h2>
    <p>Gracias por tu compra. Tu pedido ha sido procesado con éxito.</p>

    <!-- 
    Información general del pedido. 
    Aquí muestro los detalles básicos del pedido, como el número de pedido, la fecha, el total, y la dirección de envío.
    -->
    <h4>Detalles del Pedido</h4>
    <p><strong>Número de Pedido:</strong> <?php echo htmlspecialchars($pedido['id']); ?></p>
    <p><strong>Fecha:</strong> <?php echo htmlspecialchars($pedido['fecha_pedido']); ?></p>
    <p><strong>Total:</strong> €<?php echo number_format($pedido['total'], 2); ?></p>
    <p><strong>Método de Pago:</strong> <?php echo ucfirst(htmlspecialchars($pedido['metodo_pago'])); ?></p>
    <p><strong>Dirección de Envío:</strong> <?php echo htmlspecialchars($pedido['direccion_envio']); ?></p>
    <h5>Productos:</h5>

    <!-- 
    Tabla con los productos del pedido.
    Recorre cada producto del pedido para mostrarlo en la tabla.
    -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario (€)</th>
                <th>Subtotal (€)</th>
            </tr>
        </thead>
        <tbody>
            <!-- 
            Bucle para generar una fila por cada producto del pedido. 
            -->
            <?php while ($detalle = mysqli_fetch_assoc($resultado_detalles)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($detalle['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($detalle['cantidad']); ?></td>
                    <td><?php echo number_format($detalle['precio_unitario'], 2); ?></td>
                    <td><?php echo number_format($detalle['subtotal'], 2); ?></td>
                </tr>
                <!-- 
                Fin del bucle de productos.
                -->
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- 
    Botón para volver a la tienda. 
    Esto le permite al usuario seguir explorando productos después de completar su pedido.
    -->
    <a href="index.php" class="btn btn-primary">Volver a la Tienda</a>
</div>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade el pie de página, que incluye información adicional del sitio web.
-->
<?php include_once '../../includes/templates/footer.php'; ?>