<?php

/**
 * actualizar_carrito.php
 * 
 * Archivo para actualizar la cantidad de productos en el carrito.
 * 
 * Verifica y actualiza la cantidad de una variante del producto en el carrito de sesión.
 * 
 * @category Carrito
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 * @version  1.0
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * @see session_start()
 */
session_start();


/**
 * Verifica si la solicitud es de tipo POST, y si no lo es, redirige de vuelta al carrito.
 * 
 * @see $_SERVER['REQUEST_METHOD']
 * @see header()
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /**
     * Obtiene y sanitiza los datos del formulario.
     * 
     * @var string $clave ID de la variante del producto.
     * @var int    $cantidad Cantidad solicitada por el usuario, valor predeterminado 1.
     */
    $clave = isset($_POST['clave']) ? $_POST['clave'] : '';
    $cantidad = isset($_POST['cantidad']) ? intval($_POST['cantidad']) : 1;

    /**
     * Verifica si la variante existe en el carrito de sesión.
     * 
     * @see $_SESSION['carrito']
     */
    if ($clave && isset($_SESSION['carrito'][$clave])) {

        /**
         * Validar la cantidad solicitada.
         */
        if ($cantidad < 1) {
            /**
             * Si la cantidad es menor a 1, se guarda un mensaje de error en la sesión.
             * 
             * @var string $_SESSION['error'] Mensaje de error para cantidad mínima.
             */
            $_SESSION['error'] = "La cantidad debe ser al menos 1.";
        } elseif ($cantidad > intval($_SESSION['carrito'][$clave]['stock'])) {
            /**
             * Si la cantidad excede el stock disponible, se guarda un mensaje de error en la sesión.
             * 
             * @var string $_SESSION['error'] Mensaje de error por stock insuficiente.
             */
            $_SESSION['error'] = "No hay suficiente stock disponible.";
        } else {
            /**
             * Si la validación es exitosa, actualiza la cantidad en el carrito.
             * 
             * @var string $_SESSION['success'] Mensaje de éxito para cantidad actualizada.
             * 
             * @see $_SESSION['carrito']
             */
            $_SESSION['carrito'][$clave]['cantidad'] = $cantidad;
            $_SESSION['success'] = "Cantidad actualizada en el carrito.";
        }
    } else {
        /**
         * Si el producto no existe en el carrito, se guarda un mensaje de error en la sesión.
         * 
         * @var string $_SESSION['error'] Mensaje de error por producto no encontrado.
         */
        $_SESSION['error'] = "Producto no encontrado en el carrito.";
    }

    /**
     * Redirige de vuelta al carrito después de procesar.
     * 
     * @see header()
     */
    header('Location: /modaurbana/pages/cart/carrito.php');
    exit();
} else {
    /**
     * Si la solicitud no es POST, redirige al carrito.
     * 
     * @see header()
     */
    header('Location: /modaurbana/pages/cart/carrito.php');
    exit();
}
