<?php

/**
 * carrito.php
 * 
 * Página del carrito de compras.
 *
 * En esta página, yo, como usuario, puedo ver los productos añadidos al carrito,
 * actualizar las cantidades de cada producto o eliminarlos del carrito.
 *
 * @category Carrito
 * @package  ModaUrbana
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Uso esta función para acceder a los datos del carrito que están almacenados en la sesión.
 * 
 * @return void
 */
session_start();

/**
 * Incluye la conexión a la base de datos para poder realizar consultas si es necesario.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';

/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Mi carrito</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>

    <!--  
    Contenedor Principal.
    Este contenedor me permite mostrar la interfaz del carrito de compras.
    -->
    <div class="background-container">
        <div class="container-fluid mt-4">
            <br><br>
            <h2 data-aos="fade-up">Mi Carrito</h2>

            <!-- 
            Muestra mensajes de error o éxito almacenados en la sesión.
            Estos mensajes se utilizan para informar al usuario sobre el resultado de las acciones realizadas, como actualizar una cantidad o eliminar un producto.
            -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($_SESSION['error']); ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); ?></div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <!-- 
            Verifica si hay productos en el carrito.
            Si existen productos, los muestra en una tabla, permitiendo al usuario interactuar con ellos.
            -->
            <?php if (isset($_SESSION['carrito']) && count($_SESSION['carrito']) > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Imagen</th>
                            <th>Precio (€)</th>
                            <th>Talla</th>
                            <th>Color</th>
                            <th>Cantidad</th>
                            <th>Subtotal (€)</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        /**
                         * Variable para almacenar el total del carrito.
                         * Inicializo esta variable para sumar los subtotales de todos los productos.
                         */
                        $total = 0;

                        /**
                         * Itera sobre cada producto en el carrito para mostrarlos en la tabla.
                         * Cada producto se muestra con sus detalles, permitiendo al usuario interactuar con ellos.
                         */
                        foreach ($_SESSION['carrito'] as $clave => $producto):
                            /**
                             * Obtiene la talla, color y stock del producto.
                             * Si alguno de estos datos no está disponible, se muestra como "N/A".
                             */
                            $talla = isset($producto['talla']) ? htmlspecialchars($producto['talla']) : 'N/A';
                            $color = isset($producto['color']) ? htmlspecialchars($producto['color']) : 'N/A';
                            $stock = isset($producto['stock']) ? intval($producto['stock']) : 0;

                            /**
                             * Obtiene la cantidad y los precios del producto.
                             */
                            $cantidad = isset($producto['cantidad']) ? intval($producto['cantidad']) : 1;
                            $precio_original = isset($producto['precio_original']) ? floatval($producto['precio_original']) : 0.0;
                            $precio_descuento = isset($producto['precio']) ? floatval($producto['precio']) : 0.0;
                            $descuento = isset($producto['descuento']) ? floatval($producto['descuento']) : 0.0;

                            /**
                             * Calcula el subtotal por producto y lo suma al total del carrito.
                             */
                            $subtotal = $precio_descuento * $cantidad;
                            $total += $subtotal;
                        ?>
                            <tr>
                                <!-- 
                                Muestra el nombre, imagen, precio, talla y color del producto.
                                Se utiliza htmlspecialchars para evitar problemas de seguridad como XSS.
                                -->
                                <td><?php echo htmlspecialchars($producto['nombre']); ?></td>
                                <td>
                                    <img src="/modaurbana/assets/img/<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" width="50">
                                </td>
                                <td>
                                    <?php if ($descuento > 0): ?>
                                        <!-- 
                                        Muestra el precio original y el precio con descuento.
                                        El precio original se muestra tachado, y el precio con descuento en rojo y negrita.
                                        -->
                                        <del><?php echo number_format($precio_original, 2); ?>€</del><br>
                                        <strong style="color:red;"><?php echo number_format($precio_descuento, 2); ?>€</strong>
                                    <?php else: ?>
                                        <?php echo number_format($precio_original, 2); ?>€
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $talla; ?></td>
                                <td><?php echo $color; ?></td>
                                <td>
                                    <!-- 
                                    Formulario para actualizar la cantidad de un producto.
                                    Permite al usuario modificar la cantidad de productos en el carrito.
                                    -->
                                    <form method="post" action="/modaurbana/pages/cart/actualizar_carrito.php" class="d-flex align-items-center">
                                        <input type="hidden" name="clave" value="<?php echo htmlspecialchars($clave); ?>">
                                        <input type="number" name="cantidad" value="<?php echo $cantidad; ?>" min="1" max="<?php echo $stock > 0 ? $stock : 1; ?>" class="form-control" style="width: 80px; margin-right: 5px;" required>
                                        <button type="submit" class="btn btn-primary btn-sm">Actualizar</button>
                                    </form>

                                </td>
                                <!-- 
                                Muestra el subtotal del producto, calculado como cantidad * precio con descuento.
                                -->
                                <td><?php echo number_format($subtotal, 2); ?>€</td>
                                <td>
                                    <!-- 
                                    Formulario para eliminar un producto del carrito.
                                    Permite al usuario eliminar productos del carrito.
                                    -->
                                    <form method="post" action="/modaurbana/pages/cart/eliminar_del_carrito.php">
                                        <input type="hidden" name="clave" value="<?php echo htmlspecialchars($clave); ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <!-- 
                        Muestra el total del carrito.
                        Este total incluye la suma de los subtotales de todos los productos.
                        -->
                        <tr>
                            <td colspan="6" class="text-right"><strong>Total:</strong></td>
                            <td colspan="2"><strong><?php echo number_format($total, 2); ?></strong>€</td>
                        </tr>
                    </tbody>
                </table>

                <a href="/modaurbana/pages/products/tienda.php" class="btn btn-secondary">Seguir Comprando</a>
                <a href="/modaurbana/pages/cart/checkout.php" class="btn btn-success">Proceder al Pago</a>

            <?php else: ?>
                <!-- 
                Muestra un mensaje si el carrito está vacío.
                Informa al usuario de que no tiene productos en el carrito.
                -->
                <br>
                <p style="margin-left: 910px;"><strong>Tu carrito está vacío.</strong></p>
                <a href="/modaurbana/pages/products/tienda.php" class="btn btn-primary" style="margin-left: 910px;">Ir a la Tienda</a>
                <br>
            <?php endif; ?>
        </div>
    </div>

    <!-- Incluye el CSS de AOS para añadir estilos de animación -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

    <!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
    <script>
        AOS.init();
    </script>

    <!-- 
    Incluye el esqueleto del pie de la página.
    Esto añade el pie de página, que incluye información adicional del sitio web.
    -->
    <?php include_once '../../includes/templates/footer.php'; ?>

</body>

</html>