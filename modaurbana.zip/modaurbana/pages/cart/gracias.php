<?php

/**
 * gracias.php
 * 
 * Página de agradecimiento.
 * 
 * Muestra un mensaje de confirmación al usuario después de realizar un pedido.
 * También proporciona un enlace para seguir explorando la tienda.
 * 
 * @category Carrito
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */

/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto asegura que el usuario tenga una sesión activa y que podamos acceder a los datos relacionados con el pedido.
 * 
 * @return void
 */
session_start();


/**
 * Obtiene el número de pedido si está disponible en la URL o en la sesión.
 * 
 * Utilizo `$_GET` para obtener el `pedido_id` directamente desde la URL si está presente, o desde la sesión si está disponible.
 * Esto me permite mostrar el número de pedido como confirmación al usuario.
 * 
 * @var int|null $pedido_id El número del pedido que se mostrará al usuario.
 */
$pedido_id = isset($_GET['pedido_id']) ? intval($_GET['pedido_id']) : (isset($_SESSION['pedido_id']) ? intval($_SESSION['pedido_id']) : null);


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>


<!--  
Contenedor Principal.
Este contenedor muestra un mensaje de agradecimiento al usuario por su pedido y el número de pedido si está disponible.
-->
<div class="container mt-4 text-center">
    <div class="card shadow-sm p-4">
        <h2 class="text-success mb-4">¡Gracias por tu pedido!</h2>
        <p class="lead">Tu pedido ha sido procesado exitosamente. Nos pondremos en contacto contigo en caso de cualquier actualización. Revisa tu correo para los detalles del pedido.</p>

        <!-- 
        Mostrar el número de pedido si está disponible.
        Esto da al usuario un identificador único de su compra que puede utilizar para futuras consultas.
        -->
        <?php if ($pedido_id): ?>
            <p><strong>Número de pedido:</strong> <?php echo htmlspecialchars($pedido_id); ?></p>
        <?php endif; ?>

        <p class="text-muted">Puedes seguir explorando nuestras increíbles ofertas o revisar el estado de tu pedido.</p>
        <a href="/modaurbana/pages/products/tienda.php" class="btn btn-primary mt-3">Volver a la Tienda</a>
    </div>
</div>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade el pie de página, que incluye información adicional del sitio web.
-->
<?php include_once '../../includes/templates/footer.php'; ?>