<?php

/**
 * eliminar_del_carrito.php
 * 
 * Página para eliminar un producto del carrito.
 * 
 * Elimina un producto específico del carrito de la sesión del usuario.
 * 
 * @category Carrito
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */


/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Esto asegura que el usuario tenga una sesión activa antes de realizar cualquier acción sobre el carrito.
 * 
 * @return void
 */
session_start();


/**
 * Verifica que la solicitud sea de tipo POST.
 * 
 * Solo acepta solicitudes POST para eliminar un producto del carrito, ya que es una acción que modifica el estado de la aplicación.
 * 
 * @return void
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /**
     * Obtiene la clave única del producto a eliminar del carrito.
     * 
     * Esta clave identifica la variante del producto que el usuario desea eliminar.
     * 
     * @var string $clave La clave del producto que se va a eliminar.
     */
    $clave = isset($_POST['clave']) ? $_POST['clave'] : '';


    /**
     * Verifica si la clave existe en el carrito.
     * 
     * Si la clave existe, elimina el producto del carrito.
     */
    if ($clave && isset($_SESSION['carrito'][$clave])) {
        /**
         * Elimina el producto del carrito.
         * 
         * Utilizo `unset` para remover el producto del array del carrito.
         * 
         * @return void
         */
        unset($_SESSION['carrito'][$clave]);
        $_SESSION['success'] = "Producto eliminado del carrito.";
    } else {
        /**
         * Si el producto no existe en el carrito, muestro un mensaje de error.
         * 
         * Esto evita que se intenten eliminar productos que no están en el carrito.
         * 
         * @return void
         */
        $_SESSION['error'] = "Producto no encontrado en el carrito.";
    }


    /**
     * Redirige de vuelta al carrito después de procesar la eliminación.
     * 
     * Redirije al usuario a la página del carrito para que pueda ver los cambios realizados.
     * 
     * @return void
     */
    header('Location: /modaurbana/pages/cart/carrito.php');
    exit();
} else {
    /**
     * Redirige al carrito si la solicitud no es POST.
     * 
     * No permitiendo accesos a esta página por métodos que no sean POST, por lo que redirijo siempre al carrito.
     * 
     * @return void
     */
    header('Location: /modaurbana/pages/cart/carrito.php');
    exit();
}
