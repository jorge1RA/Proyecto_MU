<?php

/**
 * registro.php
 * 
 * Página de registro de nuevos usuarios en ModaUrbana.
 * Permite a los usuarios crear una cuenta proporcionando sus datos personales.
 * 
 * @category Registro
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */



/**
 * Inicia una nueva sesión o reanuda la existente.
 * 
 * Uso esta función para manejar la información del usuario durante su proceso de registro.
 * 
 * @return void
 */
session_start();


/**
 * Incluye el archivo de conexión a la base de datos.
 * 
 * Esto me permite registrar al usuario en la base de datos y realizar consultas necesarias.
 * 
 * @return void
 */
include_once '../../includes/conexion.php';


/**
 * Incluye funciones de correo electrónico.
 * 
 * Necesario para enviar un correo de bienvenida al usuario una vez registrado.
 * 
 * @return void
 */
include '../../includes/email/enviar_correo.php';


/**
 * Inicializa las variables para almacenar mensajes de error o éxito.
 * 
 * Estas variables se utilizan para mostrar mensajes al usuario después de intentar registrarse.
 * 
 * @var string $error Mensaje de error si algo falla durante el registro.
 * @var string $exito Mensaje de éxito si el registro es exitoso.
 */
$error = '';
$exito = '';


/**
 * Verifica si el formulario se ha enviado mediante una solicitud POST.
 * 
 * Utilizo esta comprobación para asegurar que el usuario está intentando registrarse.
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /**
     * Obtiene y sanitiza los datos del formulario
     * 
     * Asegura que los datos ingresados por el usuario sean seguros antes de almacenarlos.
     */
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $password_confirm = trim($_POST['password_confirm']);

    /**
     * Valida los campos del formulario para asegurarse de que están completos y correctos.
     */
    if (empty($nombre) || empty($apellidos) || empty($email) || empty($password) || empty($password_confirm)) {
        $error = "Por favor, completa todos los campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "El correo electrónico no es válido.";
    } elseif ($password !== $password_confirm) {
        $error = "Las contraseñas no coinciden.";
    } else {
        /**
         * Verifica si el correo ya está registrado en la base de datos.
         */
        $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();


        if ($stmt->num_rows > 0) {
            $error = "El correo electrónico ya está registrado.";
        } else {
            /**
             * Hashea la contraseña para almacenarla de forma segura.
             */
            $password_hashed = password_hash($password, PASSWORD_BCRYPT);

            /**
             * Inserta el nuevo usuario en la base de datos con rol de usuario y confirmado = 1.
             */
            $stmt_insert = $conexion->prepare("INSERT INTO usuarios (nombre, apellidos, email, password, rol, confirmado, fecha_registro) VALUES (?, ?, ?, ?, 'usuario', 1, NOW())");
            $stmt_insert->bind_param("ssss", $nombre, $apellidos, $email, $password_hashed);

            if ($stmt_insert->execute()) {
                /**
                 * Mensaje de éxito y envío de correo de bienvenida.
                 */
                $exito = "Registro exitoso! Bienvenido a ModaUrbana.";
                enviarCorreoBienvenida($email, $nombre);
            } else {
                /**
                 * Mensaje de error en caso de fallo al registrar el usuario.
                 */
                $error = "Hubo un error al registrar el usuario. Intenta nuevamente.";
            }

            /**
             * Cierre de sentencia preparada para insertar el usuario.
             */
            $stmt_insert->close();
        }

        /**
         * Cierre de sentencia preparada para verificar el correo electrónico.
         */
        $stmt->close();
    }
}


/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once '../../includes/templates/header.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registro Usuarios</title>
    <!-- 
    Bootstrap CSS 
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- 
    Font Awesome CSS 
    -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- 
    Estilos personalizados 
    -->
    <link rel="stylesheet" href="/modaurbana/assets/css/estilos.css?v=4">
</head>

<body>

    <!--  
    Contenedor principal de la página de registro.
    Este contenedor me permite mostrar el formulario de registro de usuario.
    -->
    <div class="background-container">
        <div class="container mt-4">
            <br><br>
            <h2 data-aos="fade-up">Registro de Usuario</h2>
            <br>
            <!-- 
            Mensaje de error si la validación falla. 
            Esto muestra un mensaje de error si ocurre un problema durante el registro.
            -->
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- 
            Mensaje de éxito si el registro es exitoso. 
            Esto muestra un mensaje de bienvenida si el registro se realiza con éxito.
            -->
            <?php if (!empty($exito)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($exito); ?></div>
            <?php endif; ?>

            <!-- 
            Formulario de registro. 
            Los usuarios deben llenar este formulario para registrarse en el sitio.
            -->
            <form method="post" action="registro.php">

                <div class="form-group">
                    <label><strong>Nombre</strong></label>
                    <input type="text" name="nombre" class="form-control" value="<?php echo isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : ''; ?>" required>
                </div>


                <div class="form-group">
                    <label><strong>Apellidos</strong></label>
                    <input type="text" name="apellidos" class="form-control" value="<?php echo isset($_POST['apellidos']) ? htmlspecialchars($_POST['apellidos']) : ''; ?>" required>
                </div>


                <div class="form-group">
                    <label><strong>Correo Electrónico</strong></label>
                    <input type="email" name="email" class="form-control" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                </div>


                <div class="form-group">
                    <label><strong>Contraseña</label>
                    <input type="password" name="password" class="form-control" required>
                </div>


                <div class="form-group">
                    <label>Confirmar Contraseña</label>
                    <input type="password" name="password_confirm" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary">Registrarse</button>
            </form>

        </div>
    </div>

</body>

</html>

<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
    Incluye el esqueleto del pie de la página. 
    Esto añade el pie de página con la información adicional del sitio.
    -->
<?php include_once '../../includes/templates/footer.php'; ?>