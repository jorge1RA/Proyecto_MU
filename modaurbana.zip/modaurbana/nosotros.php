<?php

/**
 * Incluye el esqueleto de la cabecera de la página.
 * 
 * Esto añade la parte superior de la página, incluyendo la barra de navegación y el título del sitio.
 * 
 * @return void
 */
include_once 'includes/templates/header.php';

?>

<?php
/**
 * nosotros.php
 * 
 * Página "Sobre Nosotros" - ModaUrbana.
 * Proporciona información sobre la misión, la historia y los objetivos de la tienda de moda.
 * La página describe el enfoque innovador de reutilización de prendas de vestir para promover una moda sostenible en un futuro.
 * 
 * @category Información
 * @package  ModaUrbana
 * @author   Jorge Romero Ariza
 */
?>

<!-- 
Contenedor principal con margen superior.
Este contenedor me permite mostrar toda la información sobre ModaUrbana.
-->
<div class="background-container">
    <div class="container mt-4">
        <br>
        <h2 data-aos="fade-up">Sobre Nosotros</h2>
        <div class="row">
            <div class="col-md-6">

                <!-- 
                Información sobre nuestra historia, filosofía y objetivos en ModaUrbana.
                Estos párrafos proporcionan detalles sobre el enfoque de la tienda, misión y la importancia de una moda y producción de fabricación sostenible.
                -->
                <br>
                <p data-aos="fade-right">Bienvenido a <strong>ModaUrbana</strong>, tu destino en línea para la moda más actual y vanguardista.
                    Fundada en 2024, nuestra misión es ofrecerte prendas y accesorios de alta calidad que reflejen las últimas tendencias urbanas.</p>

                <p data-aos="fade-right">En ModaUrbana, hemos creado una tienda en línea con una propuesta innovadora para transformar la forma en que compramos ropa.
                    Nuestra idea es comprar y rescatar ropa desechada y recolectada en entidades de Medio Ambiente,
                    u otras organizaciones que recogen ropa que ya no se usa, pero está en buen estado.
                    A partir de esta materia prima,
                    realizamos un proceso de tratamiento que incluye una limpieza y desinfección como selección de materiales.</p>

                <p data-aos="fade-right">Posteriormente, nuestro equipo se encarga de rediseñar estas prendas,
                    aprovechando las telas y materiales que se encuentran en mejor estado.
                    Este enfoque permite dar una segunda oportunidad a materiales que de otra forma acabarían siendo desechos y contribuye
                    a la disminución de la contaminación derivada de la industria textil, una de las más contaminantes del mundo.</p>

                <p data-aos="fade-right">Nuestro objetivo es evitar el consumismo excesivo que contribuye al deterioro del planeta,
                    y en su lugar, promover una moda circular y consciente. Queremos crear prendas únicas,
                    con diseños exclusivos, que no solo sean estéticamente atractivos, sino también significativos,
                    porque cada prenda representa un paso hacia una forma más responsable de vivir y de consumir.</p>

                <p data-aos="fade-right">¡Gracias por elegirnos y ser parte de nuestra comunidad de amantes de la moda urbana!</p>
            </div>
            <div class="col-md-6">

                <!-- 
                Imagen:
                Se añade una imagen que viste y acompaña a la información visual de "nosotros".
                La clase "img-fluid" asegura adaptabilidad a cualquier pantalla, "rounded" proporciona bordes redondeados, y el atributo "data-aos" añade una animación de zoom.
                -->
                <img src="/modaurbana/assets/img/Nosotros.jpg" alt="Equipo de ModaUrbana" class="img-fluid rounded" data-aos="zoom-in" style="height:100%;">

            </div>
        </div>

    </div>
</div>

<!-- Incluye el CSS de AOS para añadir estilos de animación -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

<!-- Incluye el JavaScript de AOS para gestionar las animaciones en el desplazamiento -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>


<!-- Enlace a las fuentes Montserrat y Playfair Display desde Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript Bundle (incluye Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>

<!-- Inicializa AOS para habilitar las animaciones de desplazamiento en la página -->
<script>
    AOS.init();
</script>

<!-- 
Incluye el esqueleto del pie de la página.
Esto añade el pie de página con la información adicional del sitio.
-->
<?php include_once 'includes/templates/footer.php'; ?>